package XSD-01.EiPayloads;


/**
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:41 PM
 */
public class eiReplyTransaction extends EiReplyTransactionType {

	public eiReplyTransaction(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}