package XSD-01.EiPayloads;


/**
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:39 PM
 */
public class eiDistributeTender extends EiDistributeTenderType {

	public eiDistributeTender(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}