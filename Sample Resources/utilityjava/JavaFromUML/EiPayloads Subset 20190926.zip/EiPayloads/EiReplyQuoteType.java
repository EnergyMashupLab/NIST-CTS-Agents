package XSD-01.EiPayloads;

import XSD-01.EIClasses.eiResponse;
import XSD-01.EIClasses.responses;
import XSD-01.EIClasses.eiQuote;

/**
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:41 PM
 */
public class EiReplyQuoteType {

	public eiResponse ext_ref_24;
	public responses ext_ref_25;
	public eiQuote ext_ref_26;

	public EiReplyQuoteType(){

	}

	public void finalize() throws Throwable {

	}

}