package XSD-01.EiPayloads;


/**
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:39 PM
 */
public class eiCreateTransaction extends EiCreateTransactionType {

	public eiCreateTransaction(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}