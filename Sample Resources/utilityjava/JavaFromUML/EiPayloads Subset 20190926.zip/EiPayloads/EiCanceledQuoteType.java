package XSD-01.EiPayloads;

import XSD-01.EIClasses.eiResponse;
import XSD-01.EIClasses.responses;
import XSD-01.EIClasses.subscriberPartyID;
import XSD-01.EIClasses.publisherPartyID;

/**
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:37 PM
 */
public class EiCanceledQuoteType {

	public eiResponse ext_ref_14;
	public responses ext_ref_15;
	public subscriberPartyID ext_ref_16;
	public publisherPartyID ext_ref_17;

	public EiCanceledQuoteType(){

	}

	public void finalize() throws Throwable {

	}

}