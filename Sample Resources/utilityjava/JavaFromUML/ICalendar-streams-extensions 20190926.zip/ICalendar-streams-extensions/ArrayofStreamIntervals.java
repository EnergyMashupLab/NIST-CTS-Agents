package ICalendar-streams-extensions;


/**
 * Collection of Stream Interval derived elements that comprise a signal partition.
 * 
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:20:10 PM
 */
public class ArrayofStreamIntervals {

	public StreamIntervalType m_StreamIntervalType;

	public ArrayofStreamIntervals(){

	}

	public void finalize() throws Throwable {

	}

}