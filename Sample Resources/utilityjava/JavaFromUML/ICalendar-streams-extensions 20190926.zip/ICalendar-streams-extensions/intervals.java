package ICalendar-streams-extensions;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:20:10 PM
 */
public class intervals extends ArrayofStreamIntervals {

	public intervals(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}