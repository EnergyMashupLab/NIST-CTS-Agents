package ICalendar-streams-extensions;


/**
 * abstract base for communication of schedules for signals and observations
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:20:10 PM
 */
public abstract class StreamBaseType {

	/**
	 * Indicates when the Designated Interval of the Stream begins. May be inherited
	 * from containing artifact.
	 */
	public xcal:DateTimeType dtstart;
	/**
	 * Indicates the duration inherited by the intervals. May be inherited from
	 * containing artifact.
	 */
	public xcal:DurationPropType duration;
	/**
	 * References an interval in the Stream as the Designated Interval. Optional.
	 * Default behavior is that the "first" interval is the Desgnated Interval
	 */
	public xcal:RelatedToPropType related-to;
	public ArrayofStreamIntervals m_ArrayofStreamIntervals;

	public StreamBaseType(){

	}

	public void finalize() throws Throwable {

	}

}