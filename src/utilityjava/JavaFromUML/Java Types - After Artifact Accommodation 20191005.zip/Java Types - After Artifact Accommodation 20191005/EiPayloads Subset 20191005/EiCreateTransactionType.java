package EiPayloads;

import EIClasses.PartyIDType;
import EIClasses.EiTransactionType;
import EIClasses.RefIDType;

/**
 * Used to create and send a Transaction.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiCreateTransactionType {

	public PartyIDType counterPartyID;
	public EiTransactionType eiTransaction;
	public PartyIDType partyID;
	public RefIDType requestID;

	public EiCreateTransactionType(){

	}

	public void finalize() throws Throwable {

	}

}