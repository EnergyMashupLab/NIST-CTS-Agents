package EiPayloads;

import EIClasses.EiDeliveryType;
import EIClasses.RefIDType;
import EIClasses.PartyIDType;

/**
 * Create Delivery passes 1 or more "empty" emix deliveries as a request to
 * receive each back with quantities filled in as eiDeliveries.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiCreateDeliveryType {

	/**
	 * emix::delivery
	 */
	public EiDeliveryType delivery;
	public RefIDType requestID;
	public PartyIDType requestorPartyID;

	public EiCreateDeliveryType(){

	}

	public void finalize() throws Throwable {

	}

}