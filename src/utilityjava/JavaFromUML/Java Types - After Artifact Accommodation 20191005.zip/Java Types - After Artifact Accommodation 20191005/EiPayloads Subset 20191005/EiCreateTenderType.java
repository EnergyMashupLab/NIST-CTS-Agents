package EiPayloads;

import EIClasses.PartyIDType;
import EIClasses.EiTenderType;
import EIClasses.RefIDType;

/**
 * Used to create and send a Tender.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiCreateTenderType {

	public PartyIDType counterPartyID;
	public EiTenderType eiTender;
	public PartyIDType partyID;
	public RefIDType requestID;

	public EiCreateTenderType(){

	}

	public void finalize() throws Throwable {

	}

}