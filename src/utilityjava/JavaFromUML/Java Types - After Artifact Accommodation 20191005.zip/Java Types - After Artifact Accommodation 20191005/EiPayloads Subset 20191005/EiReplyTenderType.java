package EiPayloads;

import EIClasses.EiResponseType;
import EIClasses.EiTenderType;

/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiReplyTenderType {

	public EiResponseType eiResponse;
	public EiTenderType eiTender;

	public EiReplyTenderType(){

	}

	public void finalize() throws Throwable {

	}

}