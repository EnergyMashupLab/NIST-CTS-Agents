package EiPayloads;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiReplyEiMarketContextType {

	public eiResponse ext_ref_50;

	public EiReplyEiMarketContextType(){

	}

	public void finalize() throws Throwable {

	}

}