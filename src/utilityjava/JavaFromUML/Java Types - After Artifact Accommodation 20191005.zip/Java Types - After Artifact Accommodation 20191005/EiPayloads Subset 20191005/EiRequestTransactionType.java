package EiPayloads;

import EIClasses.PartyIDType;
import Emix.MarketContextType;
import EIClasses.RefIDType;
import EIClasses.ArrayofStreamIntervals;
import EIClasses.TransactionIDType;

/**
 * Request extant Transactions.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiRequestTransactionType {

	public PartyIDType counterPartyID;
	public MarketContextType emixMarketContext;
	public PartyIDType partyID;
	public RefIDType requestID;
	public PartyIDType requestorPartyID;
	/**
	 * If present, limits range of request to transactions that occur within Interval.
	 */
	public ArrayofStreamIntervals streamIntervals;
	public TransactionIDType transactionID;

	public EiRequestTransactionType(){

	}

	public void finalize() throws Throwable {

	}

}