package EiPayloads;

import EIClasses.PartyIDType;
import EIClasses.EiResponseType;

/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiCanceledTenderType {

	public PartyIDType counterPartyID;
	public EiResponseType eiResponse;
	public PartyIDType partyID;

	public EiCanceledTenderType(){

	}

	public void finalize() throws Throwable {

	}

}