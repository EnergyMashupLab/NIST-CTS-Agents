package EiPayloads;

import EIClasses.PartyIDType;
import EIClasses.RefIDType;
import EIClasses.TenderIDType;

/**
 * Used to Cancel one or more Tenders.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiCancelTenderType {

	public PartyIDType counterPartyID;
	public PartyIDType partyID;
	public RefIDType requestID;
	public TenderIDType tenderID;

	public EiCancelTenderType(){

	}

	public void finalize() throws Throwable {

	}

}