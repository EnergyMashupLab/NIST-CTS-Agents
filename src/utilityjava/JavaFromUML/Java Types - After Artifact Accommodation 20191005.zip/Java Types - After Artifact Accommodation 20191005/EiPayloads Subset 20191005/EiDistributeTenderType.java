package EiPayloads;

import EIClasses.EiTenderType;
import EIClasses.PartyIDType;
import EIClasses.RefIDType;

/**
 * Used for Broadcast of Tenders.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiDistributeTenderType {

	public EiTenderType eiTender;
	public PartyIDType partyID;
	public RefIDType requestID;

	public EiDistributeTenderType(){

	}

	public void finalize() throws Throwable {

	}

}