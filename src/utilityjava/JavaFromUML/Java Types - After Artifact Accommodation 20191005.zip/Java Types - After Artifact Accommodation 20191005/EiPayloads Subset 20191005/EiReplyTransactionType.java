package EiPayloads;

import EIClasses.EiResponseType;
import EIClasses.EiTransactionType;

/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiReplyTransactionType {

	public EiResponseType eiResponse;
	public EiTransactionType eiTransaction;

	public EiReplyTransactionType(){

	}

	public void finalize() throws Throwable {

	}

}