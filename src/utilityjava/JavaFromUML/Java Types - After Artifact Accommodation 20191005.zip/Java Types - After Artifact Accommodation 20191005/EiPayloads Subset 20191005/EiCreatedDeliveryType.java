package EiPayloads;

import EIClasses.EiDeliveryType;
import EIClasses.EiResponseType;

/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:12 PM
 */
public class EiCreatedDeliveryType {

	public EiDeliveryType eiDelivery;
	public EiResponseType eiResponse;

	public EiCreatedDeliveryType(){

	}

	public void finalize() throws Throwable {

	}

}