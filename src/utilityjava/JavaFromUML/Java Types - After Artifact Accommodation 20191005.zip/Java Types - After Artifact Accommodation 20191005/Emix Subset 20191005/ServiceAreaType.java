package Emix;


/**
 * The Service Area is the geographic region that is affected by the EMIX market
 * condition
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public class ServiceAreaType extends EmixInterfaceType EmixInterfaceType {

	public ServiceAreaType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}