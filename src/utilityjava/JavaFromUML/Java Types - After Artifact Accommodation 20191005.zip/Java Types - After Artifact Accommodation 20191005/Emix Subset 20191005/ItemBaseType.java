package Emix;


/**
 * Abstract base type for units for EMIX Product delivery, measurement, and
 * warrants. Item as in PO Item, Requisition Item, Invoice Item, Lading Item. Item
 * does not include Quantity or Price, because a single product description or
 * transaction may have multiple quantities or prices associated with a single
 * item.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public abstract class ItemBaseType {

	public ItemBaseType(){

	}

	public void finalize() throws Throwable {

	}

}