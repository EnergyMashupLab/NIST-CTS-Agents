package Emix;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:37 PM
 */
public class ValueType extends decimal {

	public ValueType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}