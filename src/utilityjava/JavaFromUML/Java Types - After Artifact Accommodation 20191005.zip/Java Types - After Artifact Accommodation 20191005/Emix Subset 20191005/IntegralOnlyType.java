package Emix;


/**
 * Integral Only is an indication that the element described is [tendered] as an
 * all or nothing product. It may apply to an (amount, response, ramp) that is all
 * (true) or nothing (false)
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public class IntegralOnlyType extends boolean {

	public IntegralOnlyType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}