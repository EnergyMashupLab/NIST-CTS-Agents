package Emix;


/**
 * Multiplier times market price, 1 for same as market
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public class PriceMultiplierType extends PriceBaseType {

	public float multiplier;
	/**
	 * Market Context for  base price. If blank, Market Context from hosting artifact.
	 */
	public marketContext ref_element18;

	public PriceMultiplierType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}