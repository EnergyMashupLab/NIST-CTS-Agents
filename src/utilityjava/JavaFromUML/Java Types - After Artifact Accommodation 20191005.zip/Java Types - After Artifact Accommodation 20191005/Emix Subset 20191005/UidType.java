package Emix;


/**
 * A unique identifier for an EMIX Type. Different markets and specifications that
 * use EMIX may have their own rules for specifying an UID.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:37 PM
 */
public class UidType extends string {

	public UidType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}