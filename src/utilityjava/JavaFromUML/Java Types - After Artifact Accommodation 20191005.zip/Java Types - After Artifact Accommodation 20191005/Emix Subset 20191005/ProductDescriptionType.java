package Emix;


/**
 * In EMIX, the Product Description is placed in the Interval or Gluon attachment.
 * The respective product schemas extend this abstract class.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public abstract class ProductDescriptionType extends strm:StreamPayloadBaseType {

	public ProductDescriptionType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}