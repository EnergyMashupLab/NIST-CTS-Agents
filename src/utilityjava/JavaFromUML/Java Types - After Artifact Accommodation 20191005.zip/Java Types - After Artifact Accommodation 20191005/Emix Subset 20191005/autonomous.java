package Emix;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:34 PM
 */
public class autonomous extends AutonomousType {

	public autonomous(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}