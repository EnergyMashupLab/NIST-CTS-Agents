package Emix;


/**
 * An autonomous resource or service (true) is able to respond or maintain service
 * independently. A non autonomous service (false) must await dispatch.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:34 PM
 */
public class AutonomousType extends boolean {

	public AutonomousType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}