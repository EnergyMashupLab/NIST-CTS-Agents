package Emix;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public class MarketContextType extends anyURI {

	public MarketContextType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}