package Emix;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:37 PM
 */
public enum SideType {
	buy,
	sell
}