package Emix;

import Clm5ISO42173A.ISO3AlphaCurrencyCodeContentType;

/**
 * Currency codes coming from UN CEFACT schemas
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:34 PM
 */
public class currency {

	public currency(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}