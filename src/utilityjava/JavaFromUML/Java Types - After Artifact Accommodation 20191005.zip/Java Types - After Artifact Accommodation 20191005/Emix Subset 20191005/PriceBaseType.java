package Emix;


/**
 * Type of Abstract base for EMIX Prices
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public abstract class PriceBaseType {

	public PriceBaseType(){

	}

	public void finalize() throws Throwable {

	}

}