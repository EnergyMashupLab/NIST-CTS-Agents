package Emix;


/**
 * Type of Measurement
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public class MeasurementType extends ProductDescriptionType {

	public quantity ref_element23;
	public itemBase ref_element24;

	public MeasurementType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}