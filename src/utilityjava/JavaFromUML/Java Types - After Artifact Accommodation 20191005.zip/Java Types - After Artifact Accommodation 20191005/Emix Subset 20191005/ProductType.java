package Emix;


/**
 * EMIX Product Type, i.e. a Product Description applied to a Schedule
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public class ProductType extends EmixBaseType EmixBaseType {

	public transactiveState ref_element1;
	public expirationDate ref_element2;
	/**
	 * As part of a Tender, indicates element must be accepted in full or rejected
	 */
	public integralOnly ref_element3;
	public currency ref_element4;
	public marketContext ref_element5;
	public side ref_element6;
	public terms ref_element7;

	public ProductType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}