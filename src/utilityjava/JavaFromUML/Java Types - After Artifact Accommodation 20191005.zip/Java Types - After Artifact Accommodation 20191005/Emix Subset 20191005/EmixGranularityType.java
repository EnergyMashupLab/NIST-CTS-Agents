package Emix;


/**
 * Abstract base class used for granularity of market indications of interest and
 * tenders
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public class EmixGranularityType {

	public quantity ref_element25;
	public itemBase ref_element26;

	public EmixGranularityType(){

	}

	public void finalize() throws Throwable {

	}

}