package Emix;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public class EmixOptionType extends EmixBaseType EmixBaseType {

	public SideType optionHolderSide;
	public PriceType optionPremium;
	public PriceType optionStrikePrice;
	/**
	 * If true, each Option Call must be for the full amount specified
	 */
	public integralOnly ref_element10;
	public optionType ref_element11;
	public side ref_element12;
	public marketContext ref_element13;
	public currency ref_element14;
	public terms ref_element15;
	public transactiveState ref_element8;
	public expirationDate ref_element9;

	public EmixOptionType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}