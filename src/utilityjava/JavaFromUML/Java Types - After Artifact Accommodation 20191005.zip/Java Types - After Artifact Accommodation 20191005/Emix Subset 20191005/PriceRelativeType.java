package Emix;


/**
 * Price Relative is a fixed charge (positive or negative) apllied to base price
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public class PriceRelativeType extends PriceBaseType {

	public value ref_element19;
	/**
	 * Market Context for base price. If blank, Market Context from hosting artifact.
	 */
	public marketContext ref_element20;

	public PriceRelativeType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}