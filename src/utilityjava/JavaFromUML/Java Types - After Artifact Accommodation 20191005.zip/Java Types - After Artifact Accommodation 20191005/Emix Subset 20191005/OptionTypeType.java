package Emix;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public class OptionTypeType extends OptionTypeEnumeratedType EmixExtensionType {

	public OptionTypeType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}