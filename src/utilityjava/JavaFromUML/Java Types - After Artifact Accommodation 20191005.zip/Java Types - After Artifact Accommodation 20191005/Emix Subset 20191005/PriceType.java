package Emix;


/**
 * Simple Price
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public class PriceType extends PriceBaseType {

	public value ref_element17;

	public PriceType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}