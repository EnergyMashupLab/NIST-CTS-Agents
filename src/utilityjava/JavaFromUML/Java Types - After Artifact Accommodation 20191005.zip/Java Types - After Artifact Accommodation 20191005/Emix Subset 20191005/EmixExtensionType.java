package Emix;


/**
 * Pattern used for extending string enumeration, where allowed
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public class EmixExtensionType extends string {

	public EmixExtensionType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}