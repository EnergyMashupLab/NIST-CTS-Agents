package Emix;


/**
 * WS-Calendar Streams-derived object to host EMIX elements
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public abstract class EmixBaseType extends strm:StreamPayloadBaseType {

	public uid ref_element21;
	public envelopeContents ref_element22;

	public EmixBaseType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}