package Emix;


/**
 * Abstract base class for the interfaces for EMIX Product delivery, measurement,
 * and/or pricing
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public abstract class EmixInterfaceType {

	public EmixInterfaceType(){

	}

	public void finalize() throws Throwable {

	}

}