package Emix;


/**
 * Base type for all quanties in EMIX.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:36 PM
 */
public class QuantityType extends float {

	public QuantityType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}