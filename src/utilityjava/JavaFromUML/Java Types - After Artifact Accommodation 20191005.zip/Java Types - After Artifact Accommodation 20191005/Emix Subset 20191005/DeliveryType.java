package Emix;


/**
 * Receipt / Report of Product Delivery. Injection flag is true for adding product
 * to market supply, false for taking from market.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public class DeliveryType extends EmixBaseType EmixBaseType {

	public boolean injection;

	public DeliveryType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}