package Emix;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:46:35 PM
 */
public class EnvelopeContentsType {

	public warrants ref_element16;

	public EnvelopeContentsType(){

	}

	public void finalize() throws Throwable {

	}

}