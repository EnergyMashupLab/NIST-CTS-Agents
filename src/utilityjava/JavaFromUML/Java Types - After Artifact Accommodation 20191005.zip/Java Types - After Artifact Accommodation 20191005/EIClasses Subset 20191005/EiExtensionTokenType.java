package EIClasses;


/**
 * Pattern used for extending string enumeration, where allowed
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class EiExtensionTokenType extends token {

	public EiExtensionTokenType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}