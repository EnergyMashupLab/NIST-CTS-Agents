package EIClasses;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class EiResponseType {

	public DateTimeType createdDateTime;
	/**
	 * Identifier of the Message/Request that is is a response to
	 */
	public RefIDType refID;
	public ResponseCodeType responseCode;
	public ResponseDescriptionType responseDescription;
	public ResponseTermViolatedType responseTermsViolated;

	public EiResponseType(){

	}

	public void finalize() throws Throwable {

	}

}