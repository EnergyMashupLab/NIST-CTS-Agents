package EIClasses;

import EmixReduced.PowerProductTemixType;

/**
 * Tender is an offer to buy or sell. A Tender can be for one EmixBase derived
 * type.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class EiTenderType extends PowerProductTemixType {

	public TenderIDType tenderID;

	public EiTenderType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}