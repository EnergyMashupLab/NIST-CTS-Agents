package EIClasses;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class PartyIDType extends ActorIDType {

	public PartyIDType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}