package EIClasses;

import Ws-calendar-streams-v1.0.StreamIntervalType;

/**
 * Collection of Stream Interval derived elements that comprise a signal partition.
 * 
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class ArrayofStreamIntervals {

	public StreamIntervalType streamInterval;

	public ArrayofStreamIntervals(){

	}

	public void finalize() throws Throwable {

	}

}