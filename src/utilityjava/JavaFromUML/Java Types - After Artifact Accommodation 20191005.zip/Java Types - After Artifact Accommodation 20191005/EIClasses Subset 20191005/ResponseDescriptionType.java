package EIClasses;


/**
 * Human Readable Response description. Should be standardized and language-
 * specific.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class ResponseDescriptionType extends string {

	public ResponseDescriptionType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}