package EIClasses;


/**
 * Unique Identifier
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class UidType extends string {

	public UidType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}