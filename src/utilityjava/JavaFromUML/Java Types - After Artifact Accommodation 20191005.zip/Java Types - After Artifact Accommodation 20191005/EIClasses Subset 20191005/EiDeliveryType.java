package EIClasses;


/**
 * eiDelivery is a minimal report that assume that all esential parameters (type,
 * etc) come form an existing market context or transaction.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class EiDeliveryType extends emix:DeliveryType {

	public DateTimeType createdDateTime;
	public EiDeliveryIDType eiDeliveryID;

	public EiDeliveryType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}