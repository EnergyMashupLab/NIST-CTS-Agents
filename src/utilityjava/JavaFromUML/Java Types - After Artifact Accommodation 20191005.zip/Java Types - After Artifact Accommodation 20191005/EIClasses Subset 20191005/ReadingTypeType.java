package EIClasses;


/**
 * Type of Reading.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class ReadingTypeType extends ReadingTypeEnumeratedType EiExtensionTokenType {

	public ReadingTypeType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}