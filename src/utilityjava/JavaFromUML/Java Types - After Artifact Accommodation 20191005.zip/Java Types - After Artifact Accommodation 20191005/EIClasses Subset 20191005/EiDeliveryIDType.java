package EIClasses;


/**
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:47:27 PM
 */
public class EiDeliveryIDType extends RefIDType {

	public EiDeliveryIDType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}