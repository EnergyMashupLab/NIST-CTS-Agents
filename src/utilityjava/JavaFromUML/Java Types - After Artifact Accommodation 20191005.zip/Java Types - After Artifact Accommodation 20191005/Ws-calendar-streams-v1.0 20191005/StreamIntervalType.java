package Ws-calendar-streams-v1.0;


/**
 * Restricted variant of ws-calendar interval for streams. Stream Intervals are
 * restricted expressions of the WS-Calendar Interval that are transformable to
 * but not identical to WS-Calendar Intervals.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:50:56 PM
 */
public abstract class StreamIntervalType {

	public uid ref_element2;
	public streamPayloadBase ref_element3;

	public StreamIntervalType(){

	}

	public void finalize() throws Throwable {

	}

}