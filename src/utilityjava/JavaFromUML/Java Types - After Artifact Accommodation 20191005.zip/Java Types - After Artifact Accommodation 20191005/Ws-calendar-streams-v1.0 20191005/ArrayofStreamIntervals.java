package Ws-calendar-streams-v1.0;


/**
 * Collection of Stream Interval derived elements that comprise a signal partition.
 * 
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:50:55 PM
 */
public class ArrayofStreamIntervals {

	public streamInterval ref_element1;

	public ArrayofStreamIntervals(){

	}

	public void finalize() throws Throwable {

	}

}