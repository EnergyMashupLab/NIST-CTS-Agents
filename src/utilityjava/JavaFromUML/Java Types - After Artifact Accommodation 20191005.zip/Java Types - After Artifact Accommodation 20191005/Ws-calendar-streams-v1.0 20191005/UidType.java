package Ws-calendar-streams-v1.0;


/**
 * Unique Identifier
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:50:56 PM
 */
public class UidType extends string {

	public UidType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}