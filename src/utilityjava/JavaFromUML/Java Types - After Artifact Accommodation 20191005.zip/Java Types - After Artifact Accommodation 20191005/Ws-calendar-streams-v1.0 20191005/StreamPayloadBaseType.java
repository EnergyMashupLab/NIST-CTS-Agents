package Ws-calendar-streams-v1.0;


/**
 * Abstract class to convey a payload for a stream. When a Stream is transformed
 * to or from a WS-Calendar Interval, the contents of the Stream Payload defined
 * element are transformed into the contents of a WS-Calendar artifactBase.
 * @author crossover
 * @version 1.0
 * @created 05-Oct-2019 4:50:56 PM
 */
public abstract class StreamPayloadBaseType {

	public StreamPayloadBaseType(){

	}

	public void finalize() throws Throwable {

	}

}