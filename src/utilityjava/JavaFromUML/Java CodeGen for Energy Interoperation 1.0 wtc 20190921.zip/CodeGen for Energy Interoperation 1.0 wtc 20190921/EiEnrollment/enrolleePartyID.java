package EiEnrollment;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:01 PM
 */
public class enrolleePartyID {

	public enrolleePartyID(){

	}

	public void finalize() throws Throwable {

	}

}