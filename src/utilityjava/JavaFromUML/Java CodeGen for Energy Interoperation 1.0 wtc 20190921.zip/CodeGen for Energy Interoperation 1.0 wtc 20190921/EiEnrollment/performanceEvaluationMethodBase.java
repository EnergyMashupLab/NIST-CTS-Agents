package EiEnrollment;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:02 PM
 */
public class performanceEvaluationMethodBase extends PerformanceEvaluationMethodBaseType {

	public performanceEvaluationMethodBase(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}