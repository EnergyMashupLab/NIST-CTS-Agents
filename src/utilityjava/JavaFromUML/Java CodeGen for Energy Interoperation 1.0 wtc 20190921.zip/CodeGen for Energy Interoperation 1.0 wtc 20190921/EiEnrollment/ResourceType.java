package EiEnrollment;

import Emix.EmixInterfaceType;
import Resource.ResourceDescriptionType;

/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:02 PM
 */
public class ResourceType extends EnrolleeType {

	public EmixInterfaceType location;
	public ResourceDescriptionType resource;

	public ResourceType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}