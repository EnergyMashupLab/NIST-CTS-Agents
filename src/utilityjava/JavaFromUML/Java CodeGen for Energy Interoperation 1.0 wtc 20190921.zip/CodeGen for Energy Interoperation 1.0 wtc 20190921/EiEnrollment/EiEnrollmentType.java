package EiEnrollment;


/**
 * The enrollment of a Facility or Resource or other market participant in a
 * Market Context to participate in Energy Interoperation Services. Market
 * Enrollment is the collection of enrollment or tariff data for a Demand Resource
 * to provide a specific market product or service.  The information differs for
 * different types of enrollment as expressed by the EnrolleeType.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:01 PM
 */
public class EiEnrollmentType {

	public xcal:DateTimeType applicationDate;
	public xcal:DateTimeType effectiveDate;
	public xcal:DateTimeType endDate;
	public actorID enrollAdminPartyID;
	public EnrolleeType enrollee;
	public actorID enrolleePartyID;
	public EnrolleeTypeType enrolleeType;
	/**
	 * Comments associated with the Enrollment
	 */
	public string enrollmentComments;
	/**
	 * Reference ID  of the enrollment.
	 */
	public refID enrollmentID;
	/**
	 * Unique name (in some scope) of the enrollment.
	 */
	public string enrollmentName;
	public EnrollmentStatusType enrollmentStatus;
	/**
	 * The nature of the resource  capability, which varies for different resources.
	 * Could be a product definition as well (for Ancillary Services)
	 */
	public emix:ItemBaseType itemBase;
	public emix:MarketContextType marketContext;
	public xcal:DateTimeType modificationDateTime;
	public unsignedInt modificationNumber;
	public refID originalEnrollmentID;
	public PerformanceEvaluationMethodBaseType performanceEvaluationMethodBase;
	public PerformanceEvaluationMethodTypeBaseType performanceEvaluationMethodTypeBase;
	public ResourceType resource;

	public EiEnrollmentType(){

	}

	public void finalize() throws Throwable {

	}

}