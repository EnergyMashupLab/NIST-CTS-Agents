package EiEnrollment;

import ICalendar-valtypes.DateTimeType;

/**
 * Date of Termination of Enrollment
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:01 PM
 */
public class endDate extends DateTimeType {

	public endDate(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}