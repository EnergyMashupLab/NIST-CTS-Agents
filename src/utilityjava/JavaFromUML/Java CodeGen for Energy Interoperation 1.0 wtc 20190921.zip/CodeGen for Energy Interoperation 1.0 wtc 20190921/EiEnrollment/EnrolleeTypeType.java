package EiEnrollment;

import EIClasses.EiExtensionTokenType;

/**
 * An enumerated value that gives the type of report being provided.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:01 PM
 */
public class EnrolleeTypeType extends EiExtensionTokenType EnrolleeEnumeratedType {

	public EnrolleeTypeType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}