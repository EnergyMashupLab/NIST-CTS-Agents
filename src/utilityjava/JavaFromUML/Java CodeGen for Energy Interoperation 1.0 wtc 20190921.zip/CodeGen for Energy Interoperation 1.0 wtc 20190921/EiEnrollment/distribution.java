package EiEnrollment;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:00 PM
 */
public class distribution extends DistributionType {

	public distribution(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}