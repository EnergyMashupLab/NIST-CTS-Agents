package EiEnrollment;

import EIClasses.EiResponseType;

/**
 * Response adding information to handle Enrollment-related messages
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:01 PM
 */
public class EiEnrollmentResponseType extends EiResponseType {

	public refID enrollmentID;
	public emix:MarketContextType marketContext;
	public refID originalReferenceID;

	public EiEnrollmentResponseType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}