package EiEnrollment;

import ICalendar-valtypes.DateTimeType;

/**
 * Date of Termination of Enrollment
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:00 PM
 */
public class applicationDate extends DateTimeType {

	public applicationDate(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}