package EiEnrollment;


/**
 * Collection of Enrollment Responses. When an regards multiple referenceable
 * items, each referenced item MAY have its own response.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:00 PM
 */
public class ArrayofEnrollmentResponses {

	public EiEnrollmentResponseType enrollmentResponse;

	public ArrayofEnrollmentResponses(){

	}

	public void finalize() throws Throwable {

	}

}