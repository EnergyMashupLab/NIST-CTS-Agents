package EiEnrollment;


/**
 * The Party that is enrolling itself.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:01 PM
 */
public class EnrolleeType {

	public EnrolleeTypeType enrolleeType;
	/**
	 * A string name for the Party
	 */
	public string name;
	public actorID partyID;
	public string schemaVersion;

	public EnrolleeType(){

	}

	public void finalize() throws Throwable {

	}

}