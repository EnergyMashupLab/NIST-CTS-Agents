package EiEnrollment;


/**
 * Base for specific extensions detailing Method used to Evaluate the Performance
 * of a Resource. For IRC, based on NAESB M&V terms.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:02 PM
 */
public abstract class PerformanceEvaluationMethodBaseType {

	public PerformanceEvaluationMethodBaseType(){

	}

	public void finalize() throws Throwable {

	}

}