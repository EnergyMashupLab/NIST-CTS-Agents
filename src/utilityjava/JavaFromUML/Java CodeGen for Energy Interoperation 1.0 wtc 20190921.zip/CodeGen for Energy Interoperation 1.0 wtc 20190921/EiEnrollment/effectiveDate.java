package EiEnrollment;

import ICalendar-valtypes.DateTimeType;

/**
 * Effective Start Date for the Enrollment (when successful)
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:00 PM
 */
public class effectiveDate extends DateTimeType {

	public effectiveDate(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}