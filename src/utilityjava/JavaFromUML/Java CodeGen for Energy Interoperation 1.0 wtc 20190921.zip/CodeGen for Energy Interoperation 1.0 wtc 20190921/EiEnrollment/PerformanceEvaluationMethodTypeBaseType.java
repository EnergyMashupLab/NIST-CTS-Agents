package EiEnrollment;


/**
 * Base for IRC, a code representing the Type of Measurement used in performance
 * evaluation. The itemBase does this for simple measurements.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:02 PM
 */
public abstract class PerformanceEvaluationMethodTypeBaseType {

	public PerformanceEvaluationMethodTypeBaseType(){

	}

	public void finalize() throws Throwable {

	}

}