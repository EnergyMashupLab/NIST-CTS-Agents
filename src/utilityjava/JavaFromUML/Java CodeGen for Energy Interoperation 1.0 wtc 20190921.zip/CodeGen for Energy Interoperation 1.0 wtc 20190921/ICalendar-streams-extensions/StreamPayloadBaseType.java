package ICalendar-streams-extensions;


/**
 * Abstract class to convey a payload for a stream. When a Stream is transformed
 * to or from a WS-Calendar Interval, the contents of the Stream Payload defined
 * element are transformed into the contents of a WS-Calendar artifactBase.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:20:10 PM
 */
public abstract class StreamPayloadBaseType {

	public StreamPayloadBaseType(){

	}

	public void finalize() throws Throwable {

	}

}