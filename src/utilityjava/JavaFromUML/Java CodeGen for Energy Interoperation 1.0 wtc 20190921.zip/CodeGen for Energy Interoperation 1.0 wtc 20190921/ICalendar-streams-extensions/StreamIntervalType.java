package ICalendar-streams-extensions;

import ICalendar-props.BasePropertyType;

/**
 * Restricted variant of ws-calendar interval for streams. Stream Intervals are
 * restricted expressions of the WS-Calendar Interval that are transformable to
 * but not identical to WS-Calendar Intervals.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:20:10 PM
 */
public abstract class StreamIntervalType {

	public StreamPayloadBaseType m_StreamPayloadBaseType;
	public BasePropertyType m_BasePropertyType;

	public StreamIntervalType(){

	}

	public void finalize() throws Throwable {

	}

}