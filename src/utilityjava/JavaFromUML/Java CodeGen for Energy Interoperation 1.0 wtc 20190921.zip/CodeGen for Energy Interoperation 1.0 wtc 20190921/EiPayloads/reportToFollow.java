package EiPayloads;


/**
 * Indicates if report (in the form of UpdateReport) to be returned following
 * cancellation of Report or Historian.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class reportToFollow extends boolean {

	public reportToFollow(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}