package EiPayloads;

import EIClasses.eiResponse;
import EIClasses.venID;
import EIClasses.vtnID;
import EIClasses.eiOpt;

/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:28 PM
 */
public class EiReplyOptType {

	public eiResponse ext_ref_136;
	public venID ext_ref_137;
	public vtnID ext_ref_138;
	public eiOpt ext_ref_139;

	public EiReplyOptType(){

	}

	public void finalize() throws Throwable {

	}

}