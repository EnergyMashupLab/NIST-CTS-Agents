package EiPayloads;


/**
 * Used to request Events known to the counterparty. A VTN may ask a VEN or a VEN
 * may ask a VTN.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class EiRequestEventType {

	public pyld:EventFilterType eventFilter;
	public refID eventID;
	/**
	 * If present, limits range of request to events within the Interval. An event is
	 * within an Interval if any part of it occurs within the Interval, from the
	 * beginning of the Notification Period to the end of the Recovery Period.
	 */
	public xcal:WsCalendarIntervalType interval;
	public emix:MarketContextType marketContext;
	public unsignedInt replyLimit;
	public refID requestID;
	public actorID venID;

	public EiRequestEventType(){

	}

	public void finalize() throws Throwable {

	}

}