package EiPayloads;


/**
 * Used to cancel Historian recording, optionally requesting a final report
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:23 PM
 */
public class EiCancelHistorianType {

	/**
	 * must be the same as the target of the Report Request
	 */
	public EiTargetType eiTarget;
	public refID historianID;
	public boolean reportToFollow;

	public EiCancelHistorianType(){

	}

	public void finalize() throws Throwable {

	}

}