package EiPayloads;


/**
 * Used to modify an existing event.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:24 PM
 */
public class EiChangeEventType {

	public string changeComment;
	public EiEventType eiEvent;
	public refID requestID;
	public actorID vtnID;

	public EiChangeEventType(){

	}

	public void finalize() throws Throwable {

	}

}