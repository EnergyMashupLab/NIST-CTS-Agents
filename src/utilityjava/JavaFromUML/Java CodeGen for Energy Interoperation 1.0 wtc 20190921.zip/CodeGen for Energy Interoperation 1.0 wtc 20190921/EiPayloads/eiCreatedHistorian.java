package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:25 PM
 */
public class eiCreatedHistorian extends EiCreatedHistorianType {

	public eiCreatedHistorian(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}