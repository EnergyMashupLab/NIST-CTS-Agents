package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:25 PM
 */
public class EiCreatedPartyRegistrationType {

	public EiResponseType eiResponse;
	public actorID registrarPartyID;
	public refID registrationID;
	public actorID registreePartyID;

	public EiCreatedPartyRegistrationType(){

	}

	public void finalize() throws Throwable {

	}

}