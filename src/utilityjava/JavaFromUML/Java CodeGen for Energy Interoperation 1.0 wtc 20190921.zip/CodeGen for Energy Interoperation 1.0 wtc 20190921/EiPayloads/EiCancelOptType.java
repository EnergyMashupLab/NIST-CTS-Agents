package EiPayloads;

import EIClasses.optID;
import EIClasses.venID;

/**
 * Used to create an Opt, receiving back an Opt ID.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:23 PM
 */
public class EiCancelOptType {

	public optID ext_ref_126;
	public venID ext_ref_127;

	public EiCancelOptType(){

	}

	public void finalize() throws Throwable {

	}

}