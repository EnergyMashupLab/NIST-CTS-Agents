package EiPayloads;


/**
 * Used for Broadcast of Tenders.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class EiDistributeTenderType {

	public EiTargetType eiTarget;
	public EiTenderType eiTender;
	public actorID partyID;
	public refID requestID;

	public EiDistributeTenderType(){

	}

	public void finalize() throws Throwable {

	}

}