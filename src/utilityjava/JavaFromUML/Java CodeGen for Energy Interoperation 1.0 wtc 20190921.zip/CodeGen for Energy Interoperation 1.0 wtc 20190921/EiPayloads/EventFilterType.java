package EiPayloads;


/**
 * Used to restrict the Events exchanged in Event Requests.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public enum EventFilterType {
	/**
	 * An event qualifies if the Active Interval coincides with the Request. If
	 * specified with an accompanying Interval, an Event qualifies if any part of the
	 * Active Interval occurs within the specifying Interval; without accompanying
	 * Interval, "now" is treated as an infinitesimal Interval with a current starting
	 * date and time.
	 */
	active,
	/**
	 * An event qualifies if the Active Interval starting date and time is in the
	 * future. If specified with an accompanying Interval, the Event qualifies if the
	 * Active Interval has not started (is not Active) at the Start of the Interval,
	 * and the Active Interval start is within the bounds of the specifying Interval.
	 */
	pending,
	/**
	 * An event qualifies if it would qualify as either Active or Pending.
	 */
	all,
	/**
	 * An Event qualifies if the Active Interval is completed before the Request. If
	 * specified with an accompanying Interval, and Event qualifies if the end of the
	 * Active Interval before the start of the Requesting Interval. Conforming
	 * profiles MAY return a NULL set in response to a Request for Completed Intervals,
	 * as there is no requirement to store or be able to retrieve Completed Events.
	 */
	completed,
	/**
	 * An Event qualifies if it has been Cancelled. If specified with an accompanying
	 * Interval, and Event qualifies if the Event would have qualified as Active
	 * during the Interval. Conforming profiles MAY return a NULL set in response to a
	 * request for Completed Intervals as there is no requirement to store or be able
	 * to retrieve Cancelled Events.
	 */
	cancelled
}