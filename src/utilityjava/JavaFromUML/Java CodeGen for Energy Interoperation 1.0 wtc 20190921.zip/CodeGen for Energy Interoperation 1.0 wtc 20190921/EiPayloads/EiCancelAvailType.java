package EiPayloads;


/**
 * Used to cancel the Avail referenced by the AvailID.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:21 PM
 */
public class EiCancelAvailType {

	public refID availID;
	public actorID venID;

	public EiCancelAvailType(){

	}

	public void finalize() throws Throwable {

	}

}