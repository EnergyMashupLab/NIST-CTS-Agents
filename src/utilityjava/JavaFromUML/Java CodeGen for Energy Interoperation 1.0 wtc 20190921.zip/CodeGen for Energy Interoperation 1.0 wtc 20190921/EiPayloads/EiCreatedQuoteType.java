package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:25 PM
 */
public class EiCreatedQuoteType {

	public EiResponseType eiResponse;
	public actorID publisherPartyID;
	/**
	 * If present, the response is limited to the quote[s] with respect to the
	 * counterparty with these IDs.
	 */
	public refID quoteID;
	public ArrayOfResponses responses;
	public actorID subscriberPartyID;

	public EiCreatedQuoteType(){

	}

	public void finalize() throws Throwable {

	}

}