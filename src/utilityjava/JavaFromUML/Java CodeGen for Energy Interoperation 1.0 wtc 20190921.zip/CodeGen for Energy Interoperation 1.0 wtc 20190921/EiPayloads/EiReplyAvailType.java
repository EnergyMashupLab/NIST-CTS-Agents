package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class EiReplyAvailType {

	public EiAvailType eiAvail;
	public EiResponseType eiResponse;
	public actorID venID;
	public actorID vtnID;

	public EiReplyAvailType(){

	}

	public void finalize() throws Throwable {

	}

}