package EiPayloads;


/**
 * For event distribution through broadcast, the VTN-VEN links, or otherwise (e.g.
 * passive placing on a web site for REST-style access). This is a push, not a
 * pull.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class EiDistributeEventType {

	public EiEventType eiEvent;
	public EiTargetType eiTarget;
	public refID requestID;
	public actorID vtnID;

	public EiDistributeEventType(){

	}

	public void finalize() throws Throwable {

	}

}