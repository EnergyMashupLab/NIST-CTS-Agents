package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:24 PM
 */
public class EiChangedEventType {

	public EiResponseType eiResponse;
	public ArrayOfEventResponses eventResponses;
	public actorID venID;

	public EiChangedEventType(){

	}

	public void finalize() throws Throwable {

	}

}