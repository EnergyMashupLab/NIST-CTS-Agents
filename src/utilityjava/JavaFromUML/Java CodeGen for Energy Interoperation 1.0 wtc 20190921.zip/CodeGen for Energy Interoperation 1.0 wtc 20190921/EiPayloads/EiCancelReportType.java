package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:23 PM
 */
public class EiCancelReportType {

	public refID eiReportID;
	public EiTargetType eiTarget;
	/**
	 * self reference
	 */
	public actorID partyID;
	public refID reportRequestID;
	public boolean reportToFollow;
	public refID requestID;

	public EiCancelReportType(){

	}

	public void finalize() throws Throwable {

	}

}