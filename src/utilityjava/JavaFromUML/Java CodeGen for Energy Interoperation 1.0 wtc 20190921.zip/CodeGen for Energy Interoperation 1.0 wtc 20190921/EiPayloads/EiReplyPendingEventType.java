package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:28 PM
 */
public class EiReplyPendingEventType {

	/**
	 * Collection of IDs and Modification Numbers for Events that match the Request.
	 */
	public ei:QualifiedEventIDType ei:qualifiedEventID;
	public EiResponseType eiResponse;

	public EiReplyPendingEventType(){

	}

	public void finalize() throws Throwable {

	}

}