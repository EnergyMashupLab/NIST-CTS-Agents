package EiPayloads;

import EIClasses.venID;
import Emix.marketContext;
import EIClasses.optID;
import EIClasses.requestorPartyID;
import EIClasses.resourceID;

/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class EiRequestOptType {

	public venID ext_ref_131;
	public marketContext ext_ref_132;
	public optID ext_ref_133;
	public requestorPartyID ext_ref_134;
	public resourceID ext_ref_135;
	public requestID ref_element130;

	public EiRequestOptType(){

	}

	public void finalize() throws Throwable {

	}

}