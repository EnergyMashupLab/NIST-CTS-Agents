package EiPayloads;


/**
 * Used to create and send a Party Registration request.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class EiCreatePartyRegistrationType {

	public EiRegistrationInfoType eiRegistrationInfo;
	public actorID registreePartyID;
	public refID requestID;

	public EiCreatePartyRegistrationType(){

	}

	public void finalize() throws Throwable {

	}

}