package EiPayloads;


/**
 * Request for usage or generation [delivery] at an EMIXInterface by a requestor
 * Party, specifying interval, what is to be measured, and the direction for the
 * measurement.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:24 PM
 */
public class EiCreateDeliveryType {

	public EiDeliveryType eiDelivery;
	public refID requestID;
	public actorID requestorPartyID;

	public EiCreateDeliveryType(){

	}

	public void finalize() throws Throwable {

	}

}