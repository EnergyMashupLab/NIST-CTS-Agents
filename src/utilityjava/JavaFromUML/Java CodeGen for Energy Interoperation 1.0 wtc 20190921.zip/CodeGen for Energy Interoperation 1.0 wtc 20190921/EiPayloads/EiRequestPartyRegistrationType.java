package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class EiRequestPartyRegistrationType {

	/**
	 * If present, limits range of request to registrations within Interval.
	 */
	public xcal:WsCalendarIntervalType interval;
	public actorID registrarPartyID;
	public refID registrationID;
	public actorID registreePartyID;
	public refID requestID;
	public actorID requestorPartyID;

	public EiRequestPartyRegistrationType(){

	}

	public void finalize() throws Throwable {

	}

}