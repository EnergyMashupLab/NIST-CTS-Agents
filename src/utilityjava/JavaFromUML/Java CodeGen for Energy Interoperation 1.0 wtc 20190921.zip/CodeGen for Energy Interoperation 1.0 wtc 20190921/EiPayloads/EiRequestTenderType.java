package EiPayloads;


/**
 * Used to Request outstanding Tenders.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class EiRequestTenderType {

	public actorID counterPartyID;
	/**
	 * If present, limits range of request to tender made for products that occur
	 * within Interval.
	 */
	public xcal:WsCalendarIntervalType interval;
	public emix:MarketContextType marketContext;
	public actorID partyID;
	public refID requestID;
	public actorID requestorPartyID;
	public refID tenderID;

	public EiRequestTenderType(){

	}

	public void finalize() throws Throwable {

	}

}