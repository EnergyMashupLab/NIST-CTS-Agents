package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:28 PM
 */
public class eiReplyReport extends EiReplyReportType {

	public eiReplyReport(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}