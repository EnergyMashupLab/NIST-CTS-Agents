package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:28 PM
 */
public class EiReplyEventType {

	/**
	 * Collection of Events that match the Request.
	 */
	public EiEventType eiEvent;
	public EiResponseType eiResponse;
	public actorID venID;
	public actorID vtnID;

	public EiReplyEventType(){

	}

	public void finalize() throws Throwable {

	}

}