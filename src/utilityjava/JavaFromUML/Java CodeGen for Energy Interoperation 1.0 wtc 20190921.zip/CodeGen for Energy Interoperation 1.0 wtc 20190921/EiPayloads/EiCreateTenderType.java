package EiPayloads;


/**
 * Used to create and send a Tender.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class EiCreateTenderType {

	public actorID counterPartyID;
	public EiTenderType eiTender;
	public actorID partyID;
	public requestID ref_element203;

	public EiCreateTenderType(){

	}

	public void finalize() throws Throwable {

	}

}