package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:22 PM
 */
public class EiCanceledReportType {

	public refID eiReportID;
	public EiResponseType eiResponse;
	public refID reportRequestID;
	public ArrayOfResponses responses;

	public EiCanceledReportType(){

	}

	public void finalize() throws Throwable {

	}

}