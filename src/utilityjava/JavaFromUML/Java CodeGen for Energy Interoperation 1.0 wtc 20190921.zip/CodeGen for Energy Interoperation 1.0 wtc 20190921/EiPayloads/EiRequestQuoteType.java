package EiPayloads;


/**
 * Used to request outstanding Quotes.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class EiRequestQuoteType {

	/**
	 * If present, limits range of request to Quotes for products that occur within
	 * Interval.
	 */
	public xcal:WsCalendarIntervalType interval;
	public emix:MarketContextType marketContext;
	public actorID publisherPartyID;
	public refID quoteID;
	public refID requestID;
	public actorID requestorPartyID;

	public EiRequestQuoteType(){

	}

	public void finalize() throws Throwable {

	}

}