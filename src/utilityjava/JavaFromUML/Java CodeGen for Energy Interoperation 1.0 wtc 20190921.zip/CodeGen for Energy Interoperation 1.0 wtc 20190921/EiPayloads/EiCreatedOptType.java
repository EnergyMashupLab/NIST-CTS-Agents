package EiPayloads;

import EIClasses.eiResponse;
import EIClasses.optID;

/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:25 PM
 */
public class EiCreatedOptType {

	public eiResponse ext_ref_124;
	public optID ext_ref_125;

	public EiCreatedOptType(){

	}

	public void finalize() throws Throwable {

	}

}