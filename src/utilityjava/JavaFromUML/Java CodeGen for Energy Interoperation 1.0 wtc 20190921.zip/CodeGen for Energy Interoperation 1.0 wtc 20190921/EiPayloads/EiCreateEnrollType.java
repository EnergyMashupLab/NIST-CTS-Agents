package EiPayloads;


/**
 * Used to create and send a Enrollment.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class EiCreateEnrollType {

	public EiEnrollmentType eiEnrollment;
	public actorID enrolleePartyID;
	public refID requestID;

	public EiCreateEnrollType(){

	}

	public void finalize() throws Throwable {

	}

}