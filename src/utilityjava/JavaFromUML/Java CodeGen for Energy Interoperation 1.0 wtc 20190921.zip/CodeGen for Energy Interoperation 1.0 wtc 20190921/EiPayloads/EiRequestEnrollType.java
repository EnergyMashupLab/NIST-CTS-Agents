package EiPayloads;


/**
 * Used to request outstanding Enrollment information.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class EiRequestEnrollType {

	public actorID enrollAdminPartyID;
	public actorID enrolleePartyID;
	public refID enrollmentID;
	public emix:MarketContextType marketContext;
	public refID requestID;
	public actorID requestorPartyID;

	public EiRequestEnrollType(){

	}

	public void finalize() throws Throwable {

	}

}