package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:25 PM
 */
public class EiCreatedHistorianType {

	/**
	 * contains requestID of historian request
	 */
	public EiResponseType eiResponse;
	public refID historianID;
	public ArrayOfResponses responses;

	public EiCreatedHistorianType(){

	}

	public void finalize() throws Throwable {

	}

}