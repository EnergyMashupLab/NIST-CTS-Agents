package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class EiCreatedTransactionType {

	public actorID counterPartyID;
	public EiResponseType eiResponse;
	public actorID partyID;
	public ArrayOfResponses responses;
	public refID transactionID;

	public EiCreatedTransactionType(){

	}

	public void finalize() throws Throwable {

	}

}