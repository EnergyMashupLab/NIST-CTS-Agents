package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class eiCreateTransaction extends EiCreateTransactionType {

	public eiCreateTransaction(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}