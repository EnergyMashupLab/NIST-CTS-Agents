package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class eiCreateQuote extends EiCreateQuoteType {

	public eiCreateQuote(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}