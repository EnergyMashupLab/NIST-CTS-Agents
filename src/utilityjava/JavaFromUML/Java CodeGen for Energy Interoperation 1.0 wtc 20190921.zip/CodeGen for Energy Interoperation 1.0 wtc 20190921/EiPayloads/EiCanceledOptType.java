package EiPayloads;

import EIClasses.eiResponse;
import EIClasses.optID;

/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:22 PM
 */
public class EiCanceledOptType {

	public eiResponse ext_ref_128;
	public optID ext_ref_129;

	public EiCanceledOptType(){

	}

	public void finalize() throws Throwable {

	}

}