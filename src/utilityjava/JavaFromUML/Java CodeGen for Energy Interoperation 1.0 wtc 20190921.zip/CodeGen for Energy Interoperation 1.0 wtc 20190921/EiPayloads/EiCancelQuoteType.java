package EiPayloads;


/**
 * Used to cancel a Quote or Quotes.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:23 PM
 */
public class EiCancelQuoteType {

	public actorID publisherPartyID;
	public refID quoteID;
	public refID requestID;
	public actorID subscriberPartyID;

	public EiCancelQuoteType(){

	}

	public void finalize() throws Throwable {

	}

}