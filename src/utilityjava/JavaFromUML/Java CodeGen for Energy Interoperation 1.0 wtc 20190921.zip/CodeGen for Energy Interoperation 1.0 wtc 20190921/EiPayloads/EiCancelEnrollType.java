package EiPayloads;


/**
 * Used to cancel one or more Enrollments.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:23 PM
 */
public class EiCancelEnrollType {

	public actorID enrolleePartyID;
	public refID enrollmentID;
	public refID requestID;

	public EiCancelEnrollType(){

	}

	public void finalize() throws Throwable {

	}

}