package EiPayloads;


/**
 * Used to create and send a Quote.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class EiCreateQuoteType {

	public EiQuoteType eiQuote;
	public actorID publisherPartyID;
	public refID requestID;
	public actorID subscriberPartyID;

	public EiCreateQuoteType(){

	}

	public void finalize() throws Throwable {

	}

}