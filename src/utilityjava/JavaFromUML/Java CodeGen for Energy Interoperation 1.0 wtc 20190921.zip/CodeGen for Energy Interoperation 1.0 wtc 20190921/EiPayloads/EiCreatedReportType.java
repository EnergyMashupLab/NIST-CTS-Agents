package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:25 PM
 */
public class EiCreatedReportType {

	/**
	 * contains the reports that are ready now
	 */
	public EiReportType eiReport;
	/**
	 * contains the refID of reports that are pending
	 */
	public refID eiReportID;
	/**
	 * contains refID of report request
	 */
	public EiResponseType eiResponse;
	public ArrayOfResponses responses;

	public EiCreatedReportType(){

	}

	public void finalize() throws Throwable {

	}

}