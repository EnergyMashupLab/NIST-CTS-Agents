package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class EiUpdatedReportType {

	public EiResponseType eiResponse;

	public EiUpdatedReportType(){

	}

	public void finalize() throws Throwable {

	}

}