package EiPayloads;


/**
 * Cancel one or more Events, sent from VTN to VEN.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:23 PM
 */
public class EiCancelEventType {

	public refID eventID;
	public refID requestID;

	public EiCancelEventType(){

	}

	public void finalize() throws Throwable {

	}

}