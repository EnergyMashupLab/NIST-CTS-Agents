package EiPayloads;


/**
 * Used to Create and send a new event or modification.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class EiCreateEventType {

	public EiEventType eiEvent;
	public refID requestID;
	public actorID vtnID;

	public EiCreateEventType(){

	}

	public void finalize() throws Throwable {

	}

}