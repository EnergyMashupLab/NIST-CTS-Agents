package EiPayloads;


/**
 * For price distribution through broadcast, the VTN-VEN links, or otherwise (e.g.
 * passive placing on a web site for REST-style access).
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class EiDistributeQuoteType {

	public EiQuoteType eiQuote;
	public EiTargetType eiTarget;
	public actorID publisherPartyID;
	public refID requestID;

	public EiDistributeQuoteType(){

	}

	public void finalize() throws Throwable {

	}

}