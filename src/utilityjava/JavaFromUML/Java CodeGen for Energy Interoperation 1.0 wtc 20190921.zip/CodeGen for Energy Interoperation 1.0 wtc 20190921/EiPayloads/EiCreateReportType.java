package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class EiCreateReportType {

	public EiReportRequestType eiReportRequest;
	public actorID partyID;
	public refID requestID;
	public actorID requestorPartyID;
	public actorID vtnID;

	public EiCreateReportType(){

	}

	public void finalize() throws Throwable {

	}

}