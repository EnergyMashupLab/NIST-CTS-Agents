package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:28 PM
 */
public class EiReplyHistorianType {

	/**
	 * contains the requestID of the eiRequestHistorian
	 */
	public EiResponseType eiResponse;
	public refID historianID;
	public emix:MarketContextType marketContext;
	public ArrayOfResponses responses;

	public EiReplyHistorianType(){

	}

	public void finalize() throws Throwable {

	}

}