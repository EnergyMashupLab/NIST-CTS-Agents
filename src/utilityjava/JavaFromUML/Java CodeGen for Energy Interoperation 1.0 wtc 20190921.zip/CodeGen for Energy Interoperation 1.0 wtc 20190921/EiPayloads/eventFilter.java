package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class eventFilter extends EventFilterType {

	public eventFilter(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}