package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:22 PM
 */
public class EiCanceledEventType {

	public EiEventResponseType eiEventResponse;
	public ArrayOfEventResponses eventResponses;

	public EiCanceledEventType(){

	}

	public void finalize() throws Throwable {

	}

}