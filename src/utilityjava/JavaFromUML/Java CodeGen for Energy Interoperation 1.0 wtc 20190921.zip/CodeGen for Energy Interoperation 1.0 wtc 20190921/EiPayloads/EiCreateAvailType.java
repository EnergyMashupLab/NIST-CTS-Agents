package EiPayloads;


/**
 * Create an Avail for this VEN; return the AvailID.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:24 PM
 */
public class EiCreateAvailType {

	public EiAvailType eiAvail;

	public EiCreateAvailType(){

	}

	public void finalize() throws Throwable {

	}

}