package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:22 PM
 */
public class EiCanceledTenderType {

	public actorID counterPartyID;
	public EiResponseType eiResponse;
	public actorID partyID;
	public ArrayOfResponses responses;

	public EiCanceledTenderType(){

	}

	public void finalize() throws Throwable {

	}

}