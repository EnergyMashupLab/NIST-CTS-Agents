package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:24 PM
 */
public class eiCreateDelivery extends EiCreateDeliveryType {

	public eiCreateDelivery(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}