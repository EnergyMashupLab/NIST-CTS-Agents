package EiPayloads;


/**
 * Request extant Transactions.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class EiRequestTransactionType {

	public actorID counterPartyID;
	/**
	 * If present, limits range of request to transactions that occur within Interval.
	 */
	public xcal:WsCalendarIntervalType interval;
	public emix:MarketContextType marketContext;
	public actorID partyID;
	public refID requestID;
	public actorID requestorPartyID;
	public refID transactionID;

	public EiRequestTransactionType(){

	}

	public void finalize() throws Throwable {

	}

}