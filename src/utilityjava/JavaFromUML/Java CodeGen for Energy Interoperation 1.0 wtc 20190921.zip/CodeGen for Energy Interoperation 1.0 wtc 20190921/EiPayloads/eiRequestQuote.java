package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class eiRequestQuote extends EiRequestQuoteType {

	public eiRequestQuote(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}