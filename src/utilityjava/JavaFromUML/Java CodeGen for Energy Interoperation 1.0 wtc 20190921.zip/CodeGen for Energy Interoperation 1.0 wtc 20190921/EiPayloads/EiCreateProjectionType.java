package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class EiCreateProjectionType {

	public EiReportRequestType eiReportRequest;
	public actorID partyID;
	public refID requestID;
	public actorID requestorPartyID;
	public actorID vtnID;

	public EiCreateProjectionType(){

	}

	public void finalize() throws Throwable {

	}

}