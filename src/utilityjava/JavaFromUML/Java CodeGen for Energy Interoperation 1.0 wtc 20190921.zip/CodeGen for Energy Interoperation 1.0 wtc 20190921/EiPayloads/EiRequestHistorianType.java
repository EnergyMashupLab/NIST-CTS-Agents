package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class EiRequestHistorianType {

	/**
	 * If present, limits range of request to Histories that occur within Interval.
	 */
	public xcal:WsCalendarIntervalType interval;
	public emix:MarketContextType marketContext;
	public actorID partyID;
	public refID requestID;
	public actorID requestorPartyID;
	/**
	 * must be related to the vtn or Party that created the historian
	 */
	public actorID vtnID;

	public EiRequestHistorianType(){

	}

	public void finalize() throws Throwable {

	}

}