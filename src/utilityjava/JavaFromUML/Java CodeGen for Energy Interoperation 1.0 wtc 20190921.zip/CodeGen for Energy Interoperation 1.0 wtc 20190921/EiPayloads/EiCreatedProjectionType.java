package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:25 PM
 */
public class EiCreatedProjectionType {

	/**
	 * contains the reports that are ready now
	 */
	public EiReportType eiReport;
	/**
	 * contains the refID of reports that are pending
	 */
	public refID eiReportID;
	/**
	 * contains requestID of projection request
	 */
	public EiResponseType eiResponse;
	public ArrayOfResponses responses;

	public EiCreatedProjectionType(){

	}

	public void finalize() throws Throwable {

	}

}