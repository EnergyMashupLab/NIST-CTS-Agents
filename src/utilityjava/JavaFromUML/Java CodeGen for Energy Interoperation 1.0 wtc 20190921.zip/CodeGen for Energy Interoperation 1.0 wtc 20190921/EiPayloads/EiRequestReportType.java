package EiPayloads;


/**
 * Used to request for Report or Reports currently defined.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class EiRequestReportType {

	public EiTargetType eiTarget;
	/**
	 * If present, limits range of request to Reports that occur within Interval.
	 */
	public xcal:WsCalendarIntervalType interval;
	public actorID partyID;
	public refID reportRequestID;
	public refID requestID;
	public actorID requestorPartyID;
	public actorID vtnID;

	public EiRequestReportType(){

	}

	public void finalize() throws Throwable {

	}

}