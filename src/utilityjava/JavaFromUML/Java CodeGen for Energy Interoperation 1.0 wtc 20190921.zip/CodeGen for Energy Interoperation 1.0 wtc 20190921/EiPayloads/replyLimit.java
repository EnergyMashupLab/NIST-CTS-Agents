package EiPayloads;


/**
 * Limits Reply to first N matching artifacts.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class replyLimit extends unsignedInt {

	public replyLimit(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}