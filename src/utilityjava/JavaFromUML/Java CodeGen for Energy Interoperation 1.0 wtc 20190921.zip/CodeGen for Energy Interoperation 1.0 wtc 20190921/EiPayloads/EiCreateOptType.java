package EiPayloads;

import EIClasses.eiOpt;

/**
 * Used to create an Opt, receiving back an Opt ID.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class EiCreateOptType {

	public eiOpt ext_ref_123;

	public EiCreateOptType(){

	}

	public void finalize() throws Throwable {

	}

}