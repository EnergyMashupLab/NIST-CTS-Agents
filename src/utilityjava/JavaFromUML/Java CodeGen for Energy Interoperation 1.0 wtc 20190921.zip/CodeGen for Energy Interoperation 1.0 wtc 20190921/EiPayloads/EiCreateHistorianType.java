package EiPayloads;


/**
 * Used to create a new Historian and start it recording indicated information
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:26 PM
 */
public class EiCreateHistorianType {

	public EiReportRequestType eiReportRequest;
	public actorID partyID;
	public refID requestID;
	public actorID requestorPartyID;
	public actorID vtnID;

	public EiCreateHistorianType(){

	}

	public void finalize() throws Throwable {

	}

}