package EiPayloads;


/**
 * used to respond to CreateEvent.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:25 PM
 */
public class EiCreatedEventType {

	public EiResponseType eiResponse;
	public ArrayOfEventResponses eventResponses;
	public actorID venID;

	public EiCreatedEventType(){

	}

	public void finalize() throws Throwable {

	}

}