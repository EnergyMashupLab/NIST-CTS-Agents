package EiPayloads;


/**
 * Used to request Avail information for this VEN.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class EiRequestAvailType {

	public refID availID;
	/**
	 * If present, limits Avails returned to those within this Context.
	 */
	public emix:MarketContextType marketContext;
	public refID requestID;
	public actorID requestorPartyID;
	/**
	 * If present, limits Avails returned to those for this Resource.
	 */
	public uid resourceID;
	public actorID venID;

	public EiRequestAvailType(){

	}

	public void finalize() throws Throwable {

	}

}