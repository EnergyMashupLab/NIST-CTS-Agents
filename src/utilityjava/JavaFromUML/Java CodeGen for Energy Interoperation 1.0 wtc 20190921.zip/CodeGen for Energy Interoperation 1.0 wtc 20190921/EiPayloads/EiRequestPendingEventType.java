package EiPayloads;


/**
 * Used to request pending Events. An event is pending if any part of it occurs
 * "now", from the beginning of the Notification Period to the end of the Recovery
 * Period.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class EiRequestPendingEventType {

	public pyld:EventFilterType eventFilter;
	/**
	 * If absent, pending is defined as "this instant". If present, extends range of
	 * pending as defined in this payload.
	 */
	public xcal:WsCalendarIntervalType interval;
	public emix:MarketContextType marketContext;
	public unsignedInt replyLimit;
	public refID requestID;
	public actorID venID;

	public EiRequestPendingEventType(){

	}

	public void finalize() throws Throwable {

	}

}