package EiPayloads;


/**
 * Used to cancel one or more Party Registrations.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:23 PM
 */
public class EiCancelPartyRegistrationType {

	public actorID registrarPartyID;
	public refID registrationID;
	public actorID registreePartyID;
	public refID requestID;

	public EiCancelPartyRegistrationType(){

	}

	public void finalize() throws Throwable {

	}

}