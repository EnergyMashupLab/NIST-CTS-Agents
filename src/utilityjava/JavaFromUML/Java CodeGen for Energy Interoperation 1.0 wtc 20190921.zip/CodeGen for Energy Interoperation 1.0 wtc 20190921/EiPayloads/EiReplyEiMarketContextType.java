package EiPayloads;

import EIClasses.eiResponse;

/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class EiReplyEiMarketContextType {

	public eiResponse ext_ref_201;
	public ArrayOfResponses responses;

	public EiReplyEiMarketContextType(){

	}

	public void finalize() throws Throwable {

	}

}