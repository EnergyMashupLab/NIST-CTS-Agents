package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:30 PM
 */
public class requestID {

	public requestID(){

	}

	public void finalize() throws Throwable {

	}

}