package EiPayloads;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:29 PM
 */
public class EiRequestEiMarketContextType {

	public emix:MarketContextType marketContext;
	public actorID partyID;
	public refID requestID;
	/**
	 * Resource(s) for which status is requested.
	 */
	public uid resourceID;
	/**
	 * VEN for which Resource Status is requested.
	 */
	public actorID venID;
	public actorID vtnID;

	public EiRequestEiMarketContextType(){

	}

	public void finalize() throws Throwable {

	}

}