package EiPayloads;


/**
 * Used to create and send a Transaction.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:22:27 PM
 */
public class EiCreateTransactionType {

	public actorID counterPartyID;
	public EiTransactionType eiTransaction;
	public actorID partyID;
	public requestID ref_element234;

	public EiCreateTransactionType(){

	}

	public void finalize() throws Throwable {

	}

}