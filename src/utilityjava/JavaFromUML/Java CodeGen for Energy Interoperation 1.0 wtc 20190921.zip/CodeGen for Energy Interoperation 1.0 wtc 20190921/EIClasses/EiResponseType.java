package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class EiResponseType {

	public xcal:DateTimeType createdDateTime;
	/**
	 * Identifier of the Message/Request that is is a response to
	 */
	public refID refID;
	public EiResponseCodeType responseCode;
	public ResponseDescriptionType responseDescription;
	public ArrayOfResponseTermsViolated responseTermsViolated;

	public EiResponseType(){

	}

	public void finalize() throws Throwable {

	}

}