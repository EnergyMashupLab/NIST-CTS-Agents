package EIClasses;

import Emix.quantity;

/**
 * This is the Payload for EiDelivery.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:29 PM
 */
public class DeliveryPayloadType extends strm:StreamPayloadBaseType {

	public quantity ext_ref_73;

	public DeliveryPayloadType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}