package EIClasses;


/**
 * This is the Payload for Signals that require an EMIX Product Description.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class PayloadEmixType extends PayloadBaseType PayloadBaseType {

	public emix:ProductDescriptionType productDescription;

	public PayloadEmixType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}