package EIClasses;


/**
 * Collection of Signal Base derived elements
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:28 PM
 */
public class ArrayOfSignals {

	public eiEventSignal ref_element101;
	public eiEventBaseline ref_element102;

	public ArrayOfSignals(){

	}

	public void finalize() throws Throwable {

	}

}