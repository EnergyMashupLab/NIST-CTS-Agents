package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:27 PM
 */
public class accuracy extends AccuracyType {

	public accuracy(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}