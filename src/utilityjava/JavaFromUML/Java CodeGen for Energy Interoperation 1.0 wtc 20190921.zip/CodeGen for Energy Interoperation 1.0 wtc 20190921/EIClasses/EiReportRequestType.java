package EIClasses;


/**
 * This type is used to request an EiReport
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class EiReportRequestType {

	/**
	 * If true, aggregate all matching targets, if false, report each matching target
	 * individually.
	 */
	public boolean aggregateReport;
	public EiTargetType eiTarget;
	public refID reportRequestID;
	public ReportSchedulerType reportScheduler;
	public ReportSpecifierType reportSpecifier;
	public refID reportSpecifierID;

	public EiReportRequestType(){

	}

	public void finalize() throws Throwable {

	}

}