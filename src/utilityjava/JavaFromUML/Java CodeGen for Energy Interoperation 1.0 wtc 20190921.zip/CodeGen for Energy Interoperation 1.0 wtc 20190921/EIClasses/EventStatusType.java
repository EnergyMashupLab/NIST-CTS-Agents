package EIClasses;


/**
 * Indicates the current status of an event.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class EventStatusType extends EventStatusEnumeratedType EiExtensionTokenType {

	public EventStatusType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}