package EIClasses;


/**
 * Identifier for a Baseline.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:29 PM
 */
public class baselineID {

	public baselineID(){

	}

	public void finalize() throws Throwable {

	}

}