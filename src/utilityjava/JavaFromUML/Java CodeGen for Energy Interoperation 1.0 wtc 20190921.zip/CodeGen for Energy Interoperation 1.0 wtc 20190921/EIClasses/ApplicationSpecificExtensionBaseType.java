package EIClasses;


/**
 * Application Extensions are used to provide hints to or interactions with
 * Applications running on the other side of an interaction. They are not defined
 * in Energy Interoperation, although there are specific conformance rules that
 * must be followed
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:27 PM
 */
public abstract class ApplicationSpecificExtensionBaseType {

	public ApplicationSpecificExtensionBaseType(){

	}

	public void finalize() throws Throwable {

	}

}