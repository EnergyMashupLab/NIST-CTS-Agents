package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class ResponseTermViolatedType {

	public emix:BaseTermType baseTerm;
	public ResponseDescriptionType responseDescription;

	public ResponseTermViolatedType(){

	}

	public void finalize() throws Throwable {

	}

}