package EIClasses;

import Emix.itemBase;

/**
 * Payload for use in Report Specifiers.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class SpecifierPayloadType {

	public itemBase ext_ref_47;
	public rID ref_element46;
	public readingType ref_element48;

	public SpecifierPayloadType(){

	}

	public void finalize() throws Throwable {

	}

}