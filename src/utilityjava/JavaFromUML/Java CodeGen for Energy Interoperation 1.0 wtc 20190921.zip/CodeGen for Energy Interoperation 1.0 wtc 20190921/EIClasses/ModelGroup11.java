package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class ModelGroup11 {

	public confidence ref_element152;
	public readingType ref_element153;

	public ModelGroup11(){

	}

	public void finalize() throws Throwable {

	}

}