package EIClasses;


/**
 * This is the priority of this event relative to other events. The lower the
 * number higher the priority. A value of zero (0) indicates NO priority and in
 * essence is the lowest priority by default
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class priority extends unsignedInt {

	public priority(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}