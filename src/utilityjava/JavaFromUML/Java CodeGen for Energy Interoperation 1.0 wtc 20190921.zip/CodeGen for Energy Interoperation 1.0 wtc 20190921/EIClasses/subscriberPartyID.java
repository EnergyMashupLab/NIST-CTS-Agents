package EIClasses;


/**
 * Identifier of Party subscribing to a broadcast or service
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class subscriberPartyID {

	public subscriberPartyID(){

	}

	public void finalize() throws Throwable {

	}

}