package EIClasses;


/**
 * base for information in Signal / Baseline / Report Payloads
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public abstract class PayloadBaseType {

	public PayloadBaseType(){

	}

	public void finalize() throws Throwable {

	}

}