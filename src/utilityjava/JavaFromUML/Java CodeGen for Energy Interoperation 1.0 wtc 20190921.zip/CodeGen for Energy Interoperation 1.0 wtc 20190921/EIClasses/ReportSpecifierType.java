package EIClasses;

import ICalendar-valtypes.DurationValueType;
import ICalendar-wscal-extensions.WsCalendarIntervalType;

/**
 * Parameters that define the content of a Report Stream
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:37 PM
 */
public class ReportSpecifierType {

	/**
	 * How frequently the [measurement] is to be recorded.
	 */
	public xcal:DurationPropType granularity;
	public emix:MarketContextType marketContext;
	/**
	 * Report back with the Report-To-Date each the passing of this Duration during
	 * the Report Interval.
	 */
	public DurationValueType reportBackDuration;
	/**
	 * This is the overall period of reporting.
	 */
	public WsCalendarIntervalType reportInterval;
	public refID reportSpecifierID;
	public SpecifierPayloadType specifierPayload;

	public ReportSpecifierType(){

	}

	public void finalize() throws Throwable {

	}

}