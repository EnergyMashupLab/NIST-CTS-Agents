package EIClasses;


/**
 * Indentifier for a  superceded Reference ID
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public class originalReferenceID {

	public originalReferenceID(){

	}

	public void finalize() throws Throwable {

	}

}