package EIClasses;


/**
 * Is either a request that multiple sources be combined in a report and an
 * indication that they have been.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:27 PM
 */
public class aggregateReport extends boolean {

	public aggregateReport(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}