package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:37 PM
 */
public class responseCode extends ResponseCodeType {

	public responseCode(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}