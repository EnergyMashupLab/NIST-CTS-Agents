package EIClasses;


/**
 * Simple Levels are a set of simple indicators about scarcity and value, in which
 * an ordered set of values indicate energy scarcity is above normal, normal, or
 * below normal. Presumably, at higher levels, the VEN will use less.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class SimpleLevelContextType {

	/**
	 * The "normal" level indicating normal energy avaiability. Levels below normal
	 * indicate surplus, levels above normal indicate increasing scarcity. If
	 * levelUpperLimit is 7, the levels are 1-7, and the levelNormalValue might be 3.
	 */
	public unsignedInt levelNormalValue;
	/**
	 * The upper level for this context. If levelUpperLimit is 5, the levels are 1-5,
	 * where 5 indicates the greatest scarcity.
	 */
	public unsignedInt levelUpperLimit;

	public SimpleLevelContextType(){

	}

	public void finalize() throws Throwable {

	}

}