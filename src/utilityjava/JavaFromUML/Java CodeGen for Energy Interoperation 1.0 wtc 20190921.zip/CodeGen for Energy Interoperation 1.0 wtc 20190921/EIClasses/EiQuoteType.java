package EIClasses;

import Emix.emixBase;

/**
 * A specific offer to sell for a particular price.  A Quote can be for any number
 * of EmixBase derived types, and the Quote is treated as all-or-none.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class EiQuoteType {

	public emixBase ext_ref_136;
	public quoteID ref_element135;

	public EiQuoteType(){

	}

	public void finalize() throws Throwable {

	}

}