package EIClasses;


/**
 * Optional name for a Signal, used perhaps in a user interface.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class signalName extends string {

	public signalName(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}