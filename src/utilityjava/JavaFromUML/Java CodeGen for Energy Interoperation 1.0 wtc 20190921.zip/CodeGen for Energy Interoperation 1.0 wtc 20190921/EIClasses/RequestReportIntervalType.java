package EIClasses;


/**
 * request replaces report Interval in the Report Specification.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:37 PM
 */
public class RequestReportIntervalType extends ReportSchedulerBaseType ReportSchedulerBaseType {

	public xcal:WsCalendarIntervalType interval;

	public RequestReportIntervalType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}