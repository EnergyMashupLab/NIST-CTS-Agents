package EIClasses;


/**
 * Identifier for Acceptance of a Quote.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:27 PM
 */
public class acceptanceID {

	public acceptanceID(){

	}

	public void finalize() throws Throwable {

	}

}