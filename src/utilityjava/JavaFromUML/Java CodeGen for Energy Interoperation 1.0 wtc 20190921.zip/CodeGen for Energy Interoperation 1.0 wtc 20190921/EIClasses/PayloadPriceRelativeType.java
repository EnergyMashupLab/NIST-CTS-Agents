package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class PayloadPriceRelativeType extends PayloadBaseType {

	public emix:PriceRelativeType priceRelative;

	public PayloadPriceRelativeType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}