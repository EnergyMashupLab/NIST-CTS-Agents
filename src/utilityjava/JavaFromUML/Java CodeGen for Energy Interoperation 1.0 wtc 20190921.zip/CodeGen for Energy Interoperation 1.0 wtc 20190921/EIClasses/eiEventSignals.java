package EIClasses;


/**
 * Multiple signals conveyed with an event.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:30 PM
 */
public class eiEventSignals extends ArrayOfSignals {

	public eiEventSignals(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}