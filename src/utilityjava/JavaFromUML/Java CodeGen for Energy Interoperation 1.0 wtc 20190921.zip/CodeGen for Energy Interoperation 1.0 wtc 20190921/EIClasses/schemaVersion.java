package EIClasses;


/**
 * The version of the schema representing this entity.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class schemaVersion extends string {

	public schemaVersion(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}