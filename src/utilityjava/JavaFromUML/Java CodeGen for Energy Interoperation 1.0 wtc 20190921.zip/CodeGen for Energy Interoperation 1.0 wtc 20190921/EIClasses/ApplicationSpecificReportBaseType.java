package EIClasses;


/**
 * The Application Specific Report Base is an abstract class to exchange feedback
 * with an Application running on the other side of an interaction. They are not
 * defined in Energy Interoperation, although there are specific conformance rules
 * that must be followed
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:28 PM
 */
public abstract class ApplicationSpecificReportBaseType extends ApplicationSpecificExtensionBaseType ApplicationSpecificExtensionBaseType {

	public ApplicationSpecificReportBaseType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}