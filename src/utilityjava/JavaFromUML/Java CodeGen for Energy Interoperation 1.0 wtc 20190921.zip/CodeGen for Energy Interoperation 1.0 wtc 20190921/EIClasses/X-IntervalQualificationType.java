package EIClasses;

import ICalendar-props.BasePropertyType;

/**
 * Interval Qualification is a WS-Calendar derived property that conveys several
 * values that indicate something abvout interpreting the accuracy of the
 * information in the payload. An application that relies on this information
 * should profile precise meaings of these values withithn their domain.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:40 PM
 */
public class X-IntervalQualificationType extends BasePropertyType {

	public accuracy ref_element154;
	public ModelGroup11 m_ModelGroup11;

	public X-IntervalQualificationType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}