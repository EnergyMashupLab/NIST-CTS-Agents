package EIClasses;


/**
 * Optional name for a Transaction, used perhaps in a user interface.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class transactionName extends string {

	public transactionName(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}