package EIClasses;

import ICalendar-valtypes.DateTimeType;

/**
 * Date and Time this artifact was created.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:29 PM
 */
public class createdDateTime extends DateTimeType {

	public createdDateTime(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}