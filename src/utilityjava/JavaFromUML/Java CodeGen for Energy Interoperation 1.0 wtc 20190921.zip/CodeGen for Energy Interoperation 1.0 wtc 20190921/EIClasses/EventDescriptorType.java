package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class EventDescriptorType {

	public xcal:DateTimeType createdDateTime;
	public EiMarketContextType eiMarketContext;
	public uid eventID;
	public EventStatusType eventStatus;
	public xcal:DateTimeType modificationDateTime;
	public unsignedInt modificationNumber;
	/**
	 * The reason the event is being cancelled or modified.
	 */
	public string modificationReason;
	/**
	 * Date of Start of Event 
	 */
	public xcal:DateTimeType operatingDay;
	public unsignedInt priority;
	/**
	 * testEvent can be treated as a boolean by either not including it (= = false) or
	 * using the null string.
	 */
	public string testEvent;
	/**
	 * Additional Event information provided by the Operator [VTN].
	 */
	public string vtnComment;

	public EventDescriptorType(){

	}

	public void finalize() throws Throwable {

	}

}