package EIClasses;


/**
 * This is the identifier that may used by other entities to refer to this
 * instance of an EiConstraint.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:29 PM
 */
public class constraintID {

	public constraintID(){

	}

	public void finalize() throws Throwable {

	}

}