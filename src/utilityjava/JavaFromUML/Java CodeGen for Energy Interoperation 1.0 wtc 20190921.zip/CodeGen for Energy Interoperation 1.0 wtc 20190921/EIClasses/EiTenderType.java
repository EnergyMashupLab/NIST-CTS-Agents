package EIClasses;


/**
 * Tender Indicates a specific offer to buy or sell. A Tender can be for any
 * number of EmixBase derived types, and the Tender is treated as all-or-none.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class EiTenderType {

	public emix:EmixBaseType emixBase;
	public refID tenderID;

	public EiTenderType(){

	}

	public void finalize() throws Throwable {

	}

}