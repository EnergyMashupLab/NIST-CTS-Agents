package EIClasses;


/**
 * Indentifier of Party acting as a Registrar
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public class registrarPartyID {

	public registrarPartyID(){

	}

	public void finalize() throws Throwable {

	}

}