package EIClasses;


/**
 * Reference ID for a Report
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class eiReportID {

	public eiReportID(){

	}

	public void finalize() throws Throwable {

	}

}