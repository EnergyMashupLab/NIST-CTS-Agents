package EIClasses;


/**
 * Unique Identifier
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class UidType extends string {

	public UidType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}