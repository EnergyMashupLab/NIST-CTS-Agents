package EIClasses;


/**
 * Collection of Detailed response on Terms that cause rejection of Request
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:28 PM
 */
public class ArrayofResponseTermsViolated {

	public ResponseTermViolatedType responseTermViolated;

	public ArrayofResponseTermsViolated(){

	}

	public void finalize() throws Throwable {

	}

}