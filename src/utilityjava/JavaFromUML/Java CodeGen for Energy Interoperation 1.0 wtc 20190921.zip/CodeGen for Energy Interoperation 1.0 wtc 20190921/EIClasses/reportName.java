package EIClasses;


/**
 * Optional name for a Report, used perhaps in a user interface.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public class reportName extends string {

	public reportName(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}