package EIClasses;

import ICalendar-availability-extension.VavailabilityType;

/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:29 PM
 */
public class EiAvailType {

	/**
	 * Resource ID for the for what is offered by the VEN
	 */
	public VavailabilityType available;
	/**
	 * ID for this artifact
	 */
	public refID availID;
	public xcal:DateTimeType createdDateTime;
	public EiAvailBehaviorType eiAvailBehavior;
	public emix:MarketContextType marketContext;
	/**
	 * Resources to which the Availability applies.
	 */
	public uid resourceID;
	public string schemaVersion;
	/**
	 * VEN that offers this availability
	 */
	public actorID venID;

	public EiAvailType(){

	}

	public void finalize() throws Throwable {

	}

}