package EIClasses;


/**
 * Snap represents a single moment with the information imn the Payload is
 * Measured / Generated
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class SnapType {

	public ReportPayloadType reportPayload;
	public xcal:DateTimeType statusDateTime;

	public SnapType(){

	}

	public void finalize() throws Throwable {

	}

}