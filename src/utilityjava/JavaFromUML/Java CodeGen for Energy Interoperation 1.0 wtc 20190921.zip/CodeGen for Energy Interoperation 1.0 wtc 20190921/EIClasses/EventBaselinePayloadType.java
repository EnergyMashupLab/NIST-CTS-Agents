package EIClasses;


/**
 * Calculated Energy Baseline: A Baseline is an estimate of the electricity that
 * would have been consumed by a Demand Resource in the absence of a Demand
 * Response Event. The Baseline is compared to the actual metered electricity
 * consumption during the Demand Response Event to determine the Demand
 * Modification Value. Depending on the type of Demand Response product or service,
 * Baseline calculations may be performed in real time or after the fact. Baseline
 * may not be known at  time of event, in which case missing payload is used.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class EventBaselinePayloadType extends strm:StreamPayloadBaseType {

	public PayloadQuantityType payloadQuantity;

	public EventBaselinePayloadType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}