package EIClasses;


/**
 * Pattern used for extending string enumeration, where allowed
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:30 PM
 */
public class EiExtensionStringType extends string {

	public EiExtensionStringType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}