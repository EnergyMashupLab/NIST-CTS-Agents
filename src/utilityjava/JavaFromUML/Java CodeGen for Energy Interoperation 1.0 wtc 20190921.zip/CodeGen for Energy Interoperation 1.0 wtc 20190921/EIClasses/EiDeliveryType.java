package EIClasses;


/**
 * eiDelivery is a minimal report that assume that all esential paramters (type,
 * etc) come form an existing market context or transaction.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:30 PM
 */
public class EiDeliveryType extends strm:StreamBaseType {

	public xcal:DateTimeType createdDateTime;
	public emix:DeliveryType delivery;
	public refID eiDeliveryID;

	public EiDeliveryType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}