package EIClasses;


/**
 * The Signal Payload is a Stream Payload for conveyance within an  EiEventSignal.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class SignalPayloadType extends strm:StreamPayloadBaseType {

	public PayloadBaseType payloadBase;

	public SignalPayloadType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}