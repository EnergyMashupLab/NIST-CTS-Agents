package EIClasses;


/**
 * This is the Payload for Signals that require a Quantity.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class PayloadQuantityType extends PayloadBaseType PayloadBaseType {

	public emix:QuantityType quantity;

	public PayloadQuantityType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}