package EIClasses;


/**
 * Identifier of a Group which may be the target of an Event.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class groupID {

	public groupID(){

	}

	public void finalize() throws Throwable {

	}

}