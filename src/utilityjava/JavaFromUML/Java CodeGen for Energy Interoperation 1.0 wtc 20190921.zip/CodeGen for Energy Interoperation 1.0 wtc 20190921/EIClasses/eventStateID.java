package EIClasses;


/**
 * Identifier for an Event State interaction
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class eventStateID {

	public eventStateID(){

	}

	public void finalize() throws Throwable {

	}

}