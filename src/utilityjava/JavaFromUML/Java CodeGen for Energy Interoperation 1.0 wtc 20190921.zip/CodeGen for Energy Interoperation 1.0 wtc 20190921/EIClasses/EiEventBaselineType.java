package EIClasses;

import ICalendar-wscal-extensions.WsCalendarIntervalType;

/**
 * This type is used for describing baseline for the event.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:30 PM
 */
public class EiEventBaselineType extends strm:StreamBaseType {

	public refID baselineID;
	/**
	 * One or more Baseline Intervals indicate comprable times that MAY be used as a
	 * Baseline. Information for the Baseline Intervals is not conveyed in this type,
	 * and the Interval may be past, present, or future.
	 */
	public WsCalendarIntervalType baselineInterval;
	public string baselineName;
	public CurrentValueType currentValue;
	/**
	 * This indicates the units of the signal. 
	 */
	public emix:ItemBaseType itemBase;
	public uid resourceID;

	public EiEventBaselineType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}