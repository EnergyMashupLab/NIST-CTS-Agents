package EIClasses;

import Emix-terms.BaseTermType;

/**
 * Response Smoothing defines a Term that obligates the recipient to ensure that
 * the response not be in a single step. Response Smoothing is applied to the
 * tolerance interval[s] indicated by the Start Before, Start After, End Before,
 * and End After tolerances. Response Smoothing is implimented as a Term so it can
 * be delivered, if desired, as part of a market context.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class EiResponseSmoothingType extends BaseTermType {

	public eiSmoothing ref_element151;

	public EiResponseSmoothingType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}