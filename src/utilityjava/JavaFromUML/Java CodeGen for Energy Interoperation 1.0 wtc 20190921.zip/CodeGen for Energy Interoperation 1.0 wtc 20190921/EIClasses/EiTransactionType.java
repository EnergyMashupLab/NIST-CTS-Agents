package EIClasses;


/**
 * A Transaction is a specific agreement to accept a specific Tender or Tenders.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class EiTransactionType {

	public emix:EmixBaseType emixBase;
	public refID tenderID;
	public refID transactionID;

	public EiTransactionType(){

	}

	public void finalize() throws Throwable {

	}

}