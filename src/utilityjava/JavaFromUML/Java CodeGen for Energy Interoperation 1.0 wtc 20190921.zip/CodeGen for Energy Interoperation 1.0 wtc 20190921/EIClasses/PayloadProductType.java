package EIClasses;


/**
 * This Payload contains the information that changes in each Stream payload.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class PayloadProductType extends PayloadBaseType PayloadBaseType {

	public emix:ProductDescriptionType productDescription;

	public PayloadProductType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}