package EIClasses;


/**
 * Used if the Report Specifier includes a Report Interval to influence the
 * expression of that Interval. Information in the Gluon is inherited by the
 * Report Interval in conformance with WS-Calendar.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:37 PM
 */
public class RequestReportGluonType extends ReportSchedulerBaseType ReportSchedulerBaseType {

	public xcal:WsCalendarGluonType gluon;

	public RequestReportGluonType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}