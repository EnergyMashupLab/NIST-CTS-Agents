package EIClasses;


/**
 * Describes the subject and attributes of a report.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public class ReportDescriptionType {

	public boolean aggregateReport;
	/**
	 * What is measured or tracked in this report. Absent if report tracks Price or
	 * Level.
	 */
	public emix:ItemBaseType itemBase;
	public ReadingTypeType readingType;
	public EiTargetType reportDataSource;
	public EiTargetType reportSubject;
	public ReportTypeType reportType;
	/**
	 * Optional element for use only if more than one description.
	 */
	public rIDType rID;

	public ReportDescriptionType(){

	}

	public void finalize() throws Throwable {

	}

}