package EIClasses;


/**
 * Collection of Report and Snap Requests
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:28 PM
 */
public class ArrayOfReportRequests {

	public EiReportRequestType eiReportRequest;

	public ArrayOfReportRequests(){

	}

	public void finalize() throws Throwable {

	}

}