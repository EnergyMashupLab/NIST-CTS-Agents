package EIClasses;


/**
 * Type of Reading.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public class ReadingTypeType extends ReadingTypeEnumeratedType EiExtensionTokenType {

	public ReadingTypeType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}