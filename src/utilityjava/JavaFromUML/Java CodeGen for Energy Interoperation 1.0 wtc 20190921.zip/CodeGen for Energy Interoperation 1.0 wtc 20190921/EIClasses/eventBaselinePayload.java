package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class eventBaselinePayload extends EventBaselinePayloadType {

	public eventBaselinePayload(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}