package EIClasses;

import ICalendar-valtypes.DateTimeType;

/**
 * The date and time a modification takes effect.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public class modificationDateTime extends DateTimeType {

	public modificationDateTime(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}