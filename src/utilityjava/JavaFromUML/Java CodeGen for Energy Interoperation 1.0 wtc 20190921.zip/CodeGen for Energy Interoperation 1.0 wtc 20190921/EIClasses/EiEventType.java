package EIClasses;


/**
 * Core element of event-based demand response. An Event consists of the time
 * periods, deadlines, and transitions during which Demand Resources perform. The
 * VTN specifies the duration and applicability of an Event. Some deadlines, time
 * periods, and transitions may not be not applicable to all products or services.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:30 PM
 */
public class EiEventType {

	public xcal:VcalendarType eiActivePeriod;
	public ArrayOfSignals eiEventSignals;
	public ArrayOfReportRequests eiReportRequests;
	/**
	 * Reference ID for the EI Event instance
	 */
	public refID eventMessageID;
	public string schemaVersion;
	public EventDescriptorType m_EventDescriptorType;
	public EiTargetType m_EiTargetType;

	public EiEventType(){

	}

	public void finalize() throws Throwable {

	}

}