package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:30 PM
 */
public class EiMarketContextType {

	public ApplicationSpecificContextBaseType applicationSpecificContextBase;
	public xcal:DateTimeType createdDateTime;
	public emix:EnvelopeContentsType envelopeContents;
	public emix:MarketContextType marketContext;
	/**
	 * Name associated with the Market Context
	 */
	public string marketName;
	public ReportSpecifierType reportSpecifier;
	public string schemaVersion;
	public SimpleLevelContextType simpleLevelContext;
	public emix:StandardTermsType standardTerms;

	public EiMarketContextType(){

	}

	public void finalize() throws Throwable {

	}

}