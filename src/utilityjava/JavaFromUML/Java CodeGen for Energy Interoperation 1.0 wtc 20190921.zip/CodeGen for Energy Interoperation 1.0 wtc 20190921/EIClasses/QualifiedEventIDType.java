package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class QualifiedEventIDType {

	public refID eventID;
	public unsignedInt modificationNumber;

	public QualifiedEventIDType(){

	}

	public void finalize() throws Throwable {

	}

}