package EIClasses;


/**
 * Human Readable Response description. Should be standardized and language-
 * specific.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class ResponseDescriptionType extends string {

	public ResponseDescriptionType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}