package EIClasses;


/**
 * Report Payload for use in Reports, snaps, and projections.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public class ReportPayloadType extends strm:StreamPayloadBaseType {

	public AccuracyType accuracy;
	public ConfidenceType confidence;
	public PayloadBaseType payloadBase;
	public ReadingTypeType readingType;
	public rIDType rID;

	public ReportPayloadType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}