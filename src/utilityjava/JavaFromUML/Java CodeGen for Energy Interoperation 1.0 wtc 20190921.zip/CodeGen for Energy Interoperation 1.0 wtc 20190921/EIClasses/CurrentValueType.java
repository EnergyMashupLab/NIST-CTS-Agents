package EIClasses;


/**
 * Current Value reprises what the Signal Payload is at the moment EventInfo is
 * created.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:29 PM
 */
public class CurrentValueType {

	public PayloadBaseType payloadBase;

	public CurrentValueType(){

	}

	public void finalize() throws Throwable {

	}

}