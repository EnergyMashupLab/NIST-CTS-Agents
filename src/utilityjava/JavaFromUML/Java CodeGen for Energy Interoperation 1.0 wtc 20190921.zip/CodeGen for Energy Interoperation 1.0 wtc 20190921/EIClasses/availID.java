package EIClasses;


/**
 * Identifier for Avail in an interaction.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:28 PM
 */
public class availID {

	public availID(){

	}

	public void finalize() throws Throwable {

	}

}