package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class eventStatusEnumerated extends EventStatusEnumeratedType {

	public eventStatusEnumerated(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}