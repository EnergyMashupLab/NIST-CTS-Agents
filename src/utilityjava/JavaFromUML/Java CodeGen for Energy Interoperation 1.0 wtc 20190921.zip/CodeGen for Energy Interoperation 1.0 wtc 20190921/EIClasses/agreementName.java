package EIClasses;


/**
 * Optional Name for an Agreement between Parties, used perhaps in a user
 * interface.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:27 PM
 */
public class agreementName extends string {

	public agreementName(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}