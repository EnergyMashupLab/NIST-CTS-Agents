package EIClasses;


/**
 * Registration varies from Market to Market and VEN to VEN and so cannot be
 * defined here. Perties wishing to exchange Registration should extend this
 * abstract type to meet their particular needs.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public abstract class EiRegistrationType {

	public registreePartyID ref_element81;
	public registrarPartyID ref_element82;
	public eiRegistrationInfo ref_element83;

	public EiRegistrationType(){

	}

	public void finalize() throws Throwable {

	}

}