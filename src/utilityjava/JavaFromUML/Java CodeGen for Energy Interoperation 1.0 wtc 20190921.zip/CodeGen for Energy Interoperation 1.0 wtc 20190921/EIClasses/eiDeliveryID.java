package EIClasses;


/**
 * Reference ID for a Delivery
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:30 PM
 */
public class eiDeliveryID {

	public eiDeliveryID(){

	}

	public void finalize() throws Throwable {

	}

}