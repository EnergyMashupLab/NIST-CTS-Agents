package EIClasses;


/**
 * The Application Specific Context Base is an abstract class to exchange
 * invariant or setup information with an Application running on the other side of
 * an interaction. They are not defined in Energy Interoperation, although there
 * are specific conformance rules that must be followed
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:27 PM
 */
public abstract class ApplicationSpecificContextBaseType extends ApplicationSpecificExtensionBaseType ApplicationSpecificExtensionBaseType {

	public ApplicationSpecificContextBaseType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}