package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class eventResponses extends ArrayofEventResponses {

	public eventResponses(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}