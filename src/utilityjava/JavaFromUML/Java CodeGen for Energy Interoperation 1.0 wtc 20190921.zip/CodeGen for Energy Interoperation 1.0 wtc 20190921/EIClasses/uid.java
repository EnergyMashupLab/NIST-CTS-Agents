package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class uid extends UidType {

	public uid(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}