package EIClasses;


/**
 * This Payload contains the information that changes in each Stream payload.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public class PayloadApplicationSpecificType extends PayloadBaseType PayloadBaseType {

	public ApplicationSpecificPayloadBaseType applicationSpecificPayloadBase;

	public PayloadApplicationSpecificType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}