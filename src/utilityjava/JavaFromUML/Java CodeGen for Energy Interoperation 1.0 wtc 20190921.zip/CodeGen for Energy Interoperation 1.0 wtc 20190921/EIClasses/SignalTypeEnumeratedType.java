package EIClasses;


/**
 * SignalTypeEnumerated lists the pre-defined Types used to specify the Payload
 * Types and conformance in a Stream
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public enum SignalTypeEnumeratedType {
	/**
	 * Signal indicates the amount to change (denominated in Itembase or in the EMIX
	 * Product) from what one would have used without the Signal. This may or may not
	 * be accompanied by a baseline. Payload Type Quantity
	 */
	delta,
	/**
	 * Signal indicates a Program Level. Payload Type is Program Level
	 */
	level,
	/**
	 * Signal indicates a multiplier applied to the current rate of  delivery or usage
	 * (denominated in Itembase or in the EMIX Product) from what one would have used
	 * without the Signal. This may or may not be accompanied by a baseline. Payload
	 * Type is Float
	 */
	multiplier,
	/**
	 * Signal indicates the Price. Extended Price is the value multiplied by the
	 * number of units units (denominated in Itembase or in the EMIX Product). Payload
	 * Type is Price
	 */
	price,
	/**
	 * Signal indicates the Price. Extended Price is the value multiplied by the
	 * number of units units (denominated in Itembase or in the EMIX Product). Payload
	 * Type is Price
	 */
	priceMultiplier,
	/**
	 * Signal indicates the Product for each interval. Payload Type is an EMIX Product
	 * Description
	 */
	product,
	/**
	 * Signal indicates a target amount of units (denominated in Itembase or in the
	 * EMIX Product). Payload Type is Quantity
	 */
	setpoint,
	/**
	 * Signal indicates the Price. Extended Price is the value multiplied by the
	 * number of units units (denominated in Itembase or in the EMIX Product). Payload
	 * Type is Price
	 */
	priceRelative
}