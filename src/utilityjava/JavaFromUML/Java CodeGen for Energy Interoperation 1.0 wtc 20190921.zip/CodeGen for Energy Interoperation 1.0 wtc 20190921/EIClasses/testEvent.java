package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class testEvent extends string {

	public testEvent(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}