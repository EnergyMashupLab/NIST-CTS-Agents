package EIClasses;


/**
 * Indicates a specific level in within a simple level context. For example, a
 * context may specify a level between 1-7, and the current level is 4.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class level extends unsignedInt {

	public level(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}