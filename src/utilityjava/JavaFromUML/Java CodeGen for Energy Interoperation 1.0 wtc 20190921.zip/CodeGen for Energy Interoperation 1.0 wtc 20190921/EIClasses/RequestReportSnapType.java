package EIClasses;


/**
 * request is for a single moment status. If Empty, the request is for "when
 * received"
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:37 PM
 */
public class RequestReportSnapType extends ReportSchedulerBaseType ReportSchedulerBaseType {

	public xcal:DateTimeType statusDateTime;

	public RequestReportSnapType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}