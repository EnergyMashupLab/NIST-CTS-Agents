package EIClasses;


/**
 * Smoothing in EventSignal to indicate a requirement that a response not be in a
 * single step. Smoothing is applied to the interval[s] defined by the Start
 * Before, Start After, End Before, and End after tolerances.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public enum EiSmoothingType {
	/**
	 * A smooth or uniform step ramp is indicated between the initial and end values
	 * in the respective Tolerance Interval.
	 */
	ramp,
	/**
	 * A uniform distribution is indicated over the entire respective Tolerance
	 * Interval.
	 */
	uniform,
	/**
	 * No specific smoothing is indicated. Applications need not react in a stepwise
	 * manner, so some degree of smoothing MAY occur in response to this request. If
	 * the Smoothing Term is absent, the behavior requested is the same as None.
	 */
	none
}