package EIClasses;


/**
 * Identifier for a particular Signal
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class signalID {

	public signalID(){

	}

	public void finalize() throws Throwable {

	}

}