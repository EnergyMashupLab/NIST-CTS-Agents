package EIClasses;


/**
 * eiReport is a Stream of [measurements] recorded over time and delivered to the
 * requestor periodically. The readings may be actual, computed, summed ir derived
 * in some other manner.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class EiReportType extends strm:StreamBaseType {

	public xcal:DateTimeType createdDateTime;
	/**
	 * reference ID to this Report.
	 */
	public refUD eiReportID;
	public ReportDescriptionType reportDescription;
	/**
	 * Name possibly for use in a user interface.
	 */
	public string reportName;
	/**
	 * reference to Request that created this Report.
	 */
	public refID reportRequestID;
	/**
	 * reference to Specifier that defined this Report.
	 */
	public refID reportSpecifierID;
	public string schemaVersion;
	public SnapType snap;

	public EiReportType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}