package EIClasses;


/**
 * Identifier for the party publishing a broadcast message
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class publisherPartyID {

	public publisherPartyID(){

	}

	public void finalize() throws Throwable {

	}

}