package EIClasses;


/**
 * This type is used for describing the signal type communications.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:30 PM
 */
public class EiEventSignalType extends strm:StreamBaseType {

	public CurrentValueType currentValue;
	public EiTargetType eiTarget;
	/**
	 * This is the units of the signal. 
	 */
	public emix:ItemBaseType itemBase;
	public emix:MarketContextType marketContext;
	public string schemaVersion;
	public refID signalID;
	public string signalName;
	public SignalTypeType signalType;

	public EiEventSignalType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}