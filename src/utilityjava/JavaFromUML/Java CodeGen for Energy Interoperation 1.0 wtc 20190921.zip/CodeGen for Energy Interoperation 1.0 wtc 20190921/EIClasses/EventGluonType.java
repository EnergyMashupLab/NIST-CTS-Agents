package EIClasses;


/**
 * Establishes relation between Active Interval of an Event and the Report
 * Interval.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class EventGluonType extends ReportSchedulerBaseType ReportSchedulerBaseType {

	/**
	 * Indicates the Event this report is related to. If absent, must be delivered as
	 * part of a an EiEvent. 
	 */
	public uid eventID;
	/**
	 * Used to establish relationship between Active Interval and Report Schedule. For
	 * example, SS -T30M and FF T1H would convey that the report runs from 30 minutes
	 * before the Active Period to one hour after. If absent, the Report Interval is
	 * equivalent to the Active Interval, i.e., the Report runs during Active Interval.
	 */
	public xcal:WsCalendarGluonType gluon;

	public EventGluonType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}