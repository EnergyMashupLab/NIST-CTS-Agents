package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class EiPartyType {

	public actorID partyID;
	public string partyName;
	public string partyRole;
	public string schemaVersion;

	public EiPartyType(){

	}

	public void finalize() throws Throwable {

	}

}