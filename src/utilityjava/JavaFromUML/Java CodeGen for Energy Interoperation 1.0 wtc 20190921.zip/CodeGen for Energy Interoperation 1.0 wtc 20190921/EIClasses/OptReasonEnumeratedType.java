package EIClasses;


/**
 * Enumerated Reasons for Opting.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public enum OptReasonEnumeratedType {
	economic,
	emergency,
	mustRun,
	notParticipating,
	outageRunStatus,
	overrideStatus,
	participating
}