package EIClasses;


/**
 * Reason for Opting.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public class OptReasonType extends OptReasonEnumeratedType EiExtensionTokenType {

	public OptReasonType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}