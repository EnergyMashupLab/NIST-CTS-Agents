package EIClasses;


/**
 * Optional Name for a Market Context, used perhaps in a user interface.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class marketName extends string {

	public marketName(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}