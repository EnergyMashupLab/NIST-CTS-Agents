package EIClasses;


/**
 * Reference ID for a particular instance, transmittal, or artifact. Note: not the
 * same as the native ID of the object being transmitted or shared.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public class refID {

	public refID(){

	}

	public void finalize() throws Throwable {

	}

}