package EIClasses;


/**
 * Market Expectations inform the VEN what the expectations and rules are for a
 * given Market Context
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class EiMarketExpectationsType {

	public EiMarketRuleSetType eiMarketRuleSet;
	/**
	 * Temporal granularity of market, i.e., a 5 minute market operates in 5 minute
	 * chunks, with a fixed offset from the beginning of the business schedule
	 */
	public xcal:DurationPropType granularity;
	/**
	 * Non-Standard terms handling defines what Parties should do with any Term not
	 * listed in the Market Rule Sets.
	 */
	public emix-terms:NonStandardTermsHandlingType nonStandardTermsHandling;

	public EiMarketExpectationsType(){

	}

	public void finalize() throws Throwable {

	}

}