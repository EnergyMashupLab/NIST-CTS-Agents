package EIClasses;


/**
 * The party requesting or starting an interaction
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class initiatingPartyID {

	public initiatingPartyID(){

	}

	public void finalize() throws Throwable {

	}

}