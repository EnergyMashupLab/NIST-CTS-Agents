package EIClasses;


/**
 * A set of elements to that collectively name who is participating or should
 * participate in an EI interactions
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class EiTargetType {

	public emix:EmixInterfaceType emixInterface;
	public uid groupID;
	public string groupName;
	public actorID partyID;
	public uid resourceID;
	public actorID venID;

	public EiTargetType(){

	}

	public void finalize() throws Throwable {

	}

}