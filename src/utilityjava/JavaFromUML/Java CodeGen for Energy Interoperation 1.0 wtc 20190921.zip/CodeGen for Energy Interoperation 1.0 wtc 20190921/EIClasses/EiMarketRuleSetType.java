package EIClasses;


/**
 * A collection of Requirements (Constraints) and how they are processed within
 * this market
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class EiMarketRuleSetType {

	public EiAvailBehaviorType eiAvailBehavior;
	public RuleSetPurposeType ruleSetPurpose;
	public emix:StandardTermsSetType standardTermsSet;

	public EiMarketRuleSetType(){

	}

	public void finalize() throws Throwable {

	}

}