package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public enum OptTypeType {
	optIn,
	optOut
}