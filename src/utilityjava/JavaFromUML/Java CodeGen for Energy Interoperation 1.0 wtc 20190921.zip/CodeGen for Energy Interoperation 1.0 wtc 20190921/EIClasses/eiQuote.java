package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class eiQuote extends EiQuoteType {

	public eiQuote(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}