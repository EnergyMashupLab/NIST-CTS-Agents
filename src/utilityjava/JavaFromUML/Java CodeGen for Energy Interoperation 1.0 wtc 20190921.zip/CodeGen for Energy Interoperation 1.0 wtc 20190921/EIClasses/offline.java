package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public class offline extends boolean {

	public offline(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}