package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class payloadLevel extends PayloadLevelType {

	public payloadLevel(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}