package EIClasses;


/**
 * Identifier for Registration transaction
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public class registrationID {

	public registrationID(){

	}

	public void finalize() throws Throwable {

	}

}