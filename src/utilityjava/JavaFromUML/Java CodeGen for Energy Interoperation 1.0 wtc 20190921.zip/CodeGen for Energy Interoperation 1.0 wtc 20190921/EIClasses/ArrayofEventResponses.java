package EIClasses;


/**
 * Collection of Event Responses. When an regards multiple referenceable items,
 * each referenced item MAY have its own response. Always accompanied by an
 * overall Response Type.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:28 PM
 */
public class ArrayofEventResponses {

	public EiEventResponseType eventResponse;

	public ArrayofEventResponses(){

	}

	public void finalize() throws Throwable {

	}

}