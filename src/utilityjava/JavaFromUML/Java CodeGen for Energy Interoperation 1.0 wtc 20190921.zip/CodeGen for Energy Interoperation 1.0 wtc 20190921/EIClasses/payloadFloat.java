package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class payloadFloat extends PayloadFloatType {

	public payloadFloat(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}