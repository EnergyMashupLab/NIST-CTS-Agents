package EIClasses;

import Power.EnergyItemType;

/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:29 PM
 */
public class deployment extends EnergyItemType {

	public deployment(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}