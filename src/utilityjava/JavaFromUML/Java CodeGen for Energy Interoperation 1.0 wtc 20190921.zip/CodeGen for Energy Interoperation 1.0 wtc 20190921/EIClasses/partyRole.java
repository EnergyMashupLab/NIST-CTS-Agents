package EIClasses;


/**
 * Role that Party is assuming for this interaction, e.g buyer or seller
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public class partyRole extends string {

	public partyRole(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}