package EIClasses;


/**
 * Multiple Report and Snap Requests.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class eiReportRequests extends ArrayOfReportRequests {

	public eiReportRequests(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}