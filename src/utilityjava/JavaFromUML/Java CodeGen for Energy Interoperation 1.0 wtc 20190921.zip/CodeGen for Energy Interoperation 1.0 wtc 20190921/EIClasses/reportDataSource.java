package EIClasses;


/**
 * Sources for data in this report. Examples include meters or submeters. For
 * example, if a meter is capable of providing two different types of measurements,
 * then each measurement stream would be separately identified.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public class reportDataSource extends EiTargetType {

	public reportDataSource(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}