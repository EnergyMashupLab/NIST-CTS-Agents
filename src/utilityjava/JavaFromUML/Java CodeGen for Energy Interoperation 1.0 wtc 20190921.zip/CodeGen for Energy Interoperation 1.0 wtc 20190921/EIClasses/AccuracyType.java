package EIClasses;


/**
 * Number is in same units as the payload variable for an Interval. When present
 * with Confidence, indicates the likely variability of the prediction. When
 * present with ReadingType, indicates likely error of Reading.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:27 PM
 */
public class AccuracyType extends float {

	public AccuracyType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}