package EIClasses;


/**
 * This is the Payload for Signals that convey Simple Levels.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:35 PM
 */
public class PayloadLevelType extends PayloadBaseType PayloadBaseType {

	public unsignedInt level;

	public PayloadLevelType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}