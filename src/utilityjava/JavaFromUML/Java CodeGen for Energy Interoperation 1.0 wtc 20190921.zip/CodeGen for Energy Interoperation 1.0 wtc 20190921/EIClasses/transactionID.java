package EIClasses;


/**
 * Identification of Transaction
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class transactionID {

	public transactionID(){

	}

	public void finalize() throws Throwable {

	}

}