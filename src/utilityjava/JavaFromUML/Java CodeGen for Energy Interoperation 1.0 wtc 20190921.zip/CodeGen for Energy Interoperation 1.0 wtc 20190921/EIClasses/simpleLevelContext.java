package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class simpleLevelContext extends SimpleLevelContextType {

	public simpleLevelContext(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}