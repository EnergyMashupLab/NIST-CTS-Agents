package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public enum EventStatusEnumeratedType {
	/**
	 * No event pending
	 */
	none,
	/**
	 * event pending in the far future. The exact definition of how far in the future
	 * this refers is dependent upon the market context, but typically means the next
	 * day.
	 */
	far,
	/**
	 * event pending in the near future. The exact definition of how near in the
	 * future the pending event is active is dependent on the market context
	 */
	near,
	/**
	 * The event has been initiated and is currently active.
	 */
	active,
	/**
	 * The event has completed.
	 */
	completed,
	/**
	 * The event has been canceled.
	 */
	cancelled
}