package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class eiRegistrationInfo extends EiRegistrationInfoType {

	public eiRegistrationInfo(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}