package EIClasses;


/**
 * Identifier assigned to an Event, carried in the Event Descriptor.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class eventID {

	public eventID(){

	}

	public void finalize() throws Throwable {

	}

}