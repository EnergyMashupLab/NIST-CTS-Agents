package EIClasses;


/**
 * Opts are used tby the VEN to make temporary over-rides to the pre-existing
 * agreement. For example, a VEN may Opt In to events during the evening, or Opt
 * Out from events during the World Series.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class EiOptType {

	public xcal:DateTimeType createdDateTime;
	public EiMarketRuleSetType eiMarketRuleSet;
	public MarketContextType marketContext;
	/**
	 * This is the identifier that may used by other entities to refer to this
	 * instance of an OptOut.
	 * 			
	 */
	public refID optID;
	public OptReasonType optReason;
	public OptTypeType optType;
	public string schemaVersion;
	public iCalendar-availability-extension::VavailabilityType vavailability;
	public actorID venID;

	public EiOptType(){

	}

	public void finalize() throws Throwable {

	}

}