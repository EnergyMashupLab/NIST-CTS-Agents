package EIClasses;


/**
 * Identifier assigned to the message (EiEvent) describing an event and it
 * associated signals.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class eventMessageID {

	public eventMessageID(){

	}

	public void finalize() throws Throwable {

	}

}