package EIClasses;


/**
 * A modification number for [event]. Used to indicate if the [event] has been
 * modified and is incremented each time the [event] is modified
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:34 PM
 */
public class modificationNumber extends unsignedInt {

	public modificationNumber(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}