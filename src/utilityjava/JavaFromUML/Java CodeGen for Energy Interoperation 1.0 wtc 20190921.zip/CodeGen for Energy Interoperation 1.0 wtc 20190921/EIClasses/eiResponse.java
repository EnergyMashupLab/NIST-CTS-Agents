package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:32 PM
 */
public class eiResponse extends EiResponseType {

	public eiResponse(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}