package EIClasses;


/**
 * Identifier of Party making a Resonse (note: in CancelledPartyRegistration
 * payload and I do not know defintion)
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:37 PM
 */
public class respondingPartyID {

	public respondingPartyID(){

	}

	public void finalize() throws Throwable {

	}

}