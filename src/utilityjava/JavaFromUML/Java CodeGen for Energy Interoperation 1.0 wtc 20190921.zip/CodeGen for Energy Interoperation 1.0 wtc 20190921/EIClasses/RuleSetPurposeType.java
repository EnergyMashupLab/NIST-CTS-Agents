package EIClasses;


/**
 * Defines the purpose of a market rule set.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public enum RuleSetPurposeType {
	/**
	 * The Market does not accept this Term with a parameter set to a lesser value
	 * than this
	 */
	minimum,
	/**
	 * The Market does not accept this Term with a parameter set to a greater value
	 * than this
	 */
	maximum,
	/**
	 * Regardless of what the market participant requests, force the Term to the value
	 * here.
	 */
	force,
	/**
	 * Participants in this market must understand this constraint.
	 */
	mustUnderstand,
	/**
	 * This Constraint will be ignored in all its forms.
	 */
	ignore
}