package EIClasses;


/**
 * Enumerated Report types
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:36 PM
 */
public enum ReportEnumeratedType {
	/**
	 * Report indicates a Reading, as from a meter. Readings are moments in time--
	 * changes over time can be computed from the difference between successive
	 * readings. Payload Type is Float
	 */
	reading,
	/**
	 * Report indicates an amount of units (denominated in Itembase or in the EMIX
	 * Product) over a period. Payload Type is Quantity. A typical ItemBase is Real
	 * Energy.
	 */
	usage,
	/**
	 * Report indicates an amount of units (denominated in Itembase or in the EMIX
	 * Product). Payload Type is Quantity. A typical ItemBase is Real Power.
	 */
	demand,
	/**
	 * Report indicates the amount (denominated in Itembase or in the EMIX Product)
	 * currently set. May be a confirmation/return of the setpoint control value sent
	 * from the VTN. Payload Type is Quantity. A typical ItemBase is Real Power.
	 */
	setPoint,
	/**
	 * Change in Usage as compared to the Baseline. See usage for more information
	 */
	deltaUsage,
	/**
	 * Changes in Setpoint from previous schedule.
	 */
	deltaSetPoint,
	/**
	 * Change in Demand as compared to the Baseline. See Demand for more information
	 */
	deltaDemand,
	/**
	 * Can be Demand or Usage, as indicated by ItemBase. Indicates what [measurement[
	 * would be if not for the Event or Regulation. Report is of the format Baseline.
	 */
	baseline,
	/**
	 * Difference between some instruction and actual state.
	 */
	deviation,
	/**
	 * Average usage over the duration indicated by the Granularity. See usage for
	 * more information,
	 */
	avgUsage,
	/**
	 * Average usage over the duration indicated by the Granularity. See demand for
	 * more information.
	 */
	avgDemand,
	/**
	 * Generalized state of a resource such as on/off, occupancy of building, etc. No
	 * ItemBase is relevant. Requires an Application Specific Payload Extension.
	 */
	operatingState,
	/**
	 * Up Regulation capacity available for dispatch, expressed in EMIX Real Power.
	 * Payload is always expressed as positive Quantity.
	 */
	upRegulationCapacityAvailable,
	/**
	 * Down Regulation capacity available for dispatch, expressed in EMIX Real Power.
	 * Payload is always expressed as positive Quantity.
	 */
	downRegulationCapacityAvailable,
	/**
	 * Regulation setpoint as instructed as part of regulation services
	 */
	regulationSetpoint,
	/**
	 * Stored Energy is expressed as as Real Energy and Payload is expressed as a
	 * Quantity.
	 */
	storedEnergy,
	/**
	 * Target Energy is expressed as as Real Energy and Payload is expressed as a
	 * Quantity.
	 */
	targetEnergyStorage,
	/**
	 * Capacity available for further energy storage, perhaps to get to Target Energy
	 * Storage
	 */
	availableEnergyStorage,
	/**
	 * Price per ItemBase at each Interval
	 */
	price,
	/**
	 * Simple level from market at each Interval. Itemabse is not relevant.
	 */
	level
}