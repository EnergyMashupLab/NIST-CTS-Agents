package EIClasses;


/**
 * ID for internal use in reports
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class rIDType extends string {

	public rIDType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}