package EIClasses;


/**
 * This is the type for an Interval in a Signal / Baseline / Report Stream.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:33 PM
 */
public class IntervalType extends strm:StreamIntervalType {

	public IntervalType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}