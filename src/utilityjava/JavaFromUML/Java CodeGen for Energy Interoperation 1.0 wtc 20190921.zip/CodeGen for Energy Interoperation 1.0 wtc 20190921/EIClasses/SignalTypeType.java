package EIClasses;


/**
 * SignalType is used in EventSignals to specify the Payload Types in a Signal.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class SignalTypeType extends SignalTypeEnumeratedType EiExtensionTokenType {

	public SignalTypeType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}