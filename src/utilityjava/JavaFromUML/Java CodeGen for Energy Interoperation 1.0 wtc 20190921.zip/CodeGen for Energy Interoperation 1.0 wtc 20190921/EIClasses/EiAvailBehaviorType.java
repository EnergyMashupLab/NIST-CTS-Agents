package EIClasses;


/**
 * When an Event is issued by the VTN, it is validated against the parameters and
 * constraints that were established when the program [market context] was set up,
 * i.e., the program was configured to support Events between 12:00 and 16:00.  If
 * the Event is not within 12:00 and 16:00 then VEN must take some action to
 * resolve the conflict.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:29 PM
 */
public enum EiAvailBehaviorType {
	/**
	 * Simply accept the issued DR event regardless of any conflicts
	 */
	accept,
	/**
	 * Reject any DR events that conflict with configured constraints
	 */
	reject,
	/**
	 * Modify the DR event parameters so that they legally fall within the bounds of
	 * the configured parameters.
	 */
	restrict
}