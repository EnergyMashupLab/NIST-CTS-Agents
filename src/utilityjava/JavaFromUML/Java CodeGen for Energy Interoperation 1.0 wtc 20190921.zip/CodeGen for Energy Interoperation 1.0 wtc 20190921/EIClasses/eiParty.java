package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:31 PM
 */
public class eiParty extends EiPartyType {

	public eiParty(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}