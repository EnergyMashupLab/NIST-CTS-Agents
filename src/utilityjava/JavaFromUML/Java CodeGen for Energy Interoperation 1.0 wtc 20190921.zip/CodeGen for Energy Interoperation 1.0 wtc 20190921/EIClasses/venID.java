package EIClasses;


/**
 * Identifier of Party acting as a VEN.
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class venID {

	public venID(){

	}

	public void finalize() throws Throwable {

	}

}