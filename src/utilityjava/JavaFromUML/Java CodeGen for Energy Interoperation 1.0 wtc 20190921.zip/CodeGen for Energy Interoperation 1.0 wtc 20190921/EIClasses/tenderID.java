package EIClasses;


/**
 * Identifier for a market Tender
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:39 PM
 */
public class tenderID {

	public tenderID(){

	}

	public void finalize() throws Throwable {

	}

}