package EIClasses;


/**
 * @author wtcox
 * @version 1.0
 * @created 21-Sep-2019 7:21:38 PM
 */
public class responses extends ArrayofResponses {

	public responses(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}