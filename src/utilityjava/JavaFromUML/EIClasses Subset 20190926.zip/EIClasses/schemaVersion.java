package XSD-01.EIClasses;


/**
 * The version of the schema representing this entity.
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:54 PM
 */
public class schemaVersion extends string {

	public schemaVersion(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}