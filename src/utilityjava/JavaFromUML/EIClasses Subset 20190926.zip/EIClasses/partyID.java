package XSD-01.EIClasses;


/**
 * Identifier for any Party
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:49 PM
 */
public class partyID {

	public partyID(){

	}

	public void finalize() throws Throwable {

	}

}