package XSD-01.EIClasses;


/**
 * Identifier of Party making a Request
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:53 PM
 */
public class requestorPartyID {

	public requestorPartyID(){

	}

	public void finalize() throws Throwable {

	}

}