package XSD-01.EIClasses;


/**
 * Indentifier of Party acting as a Registrar
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:53 PM
 */
public class registrarPartyID {

	public registrarPartyID(){

	}

	public void finalize() throws Throwable {

	}

}