package XSD-01.EIClasses;


/**
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:53 PM
 */
public class responseCode extends ResponseCodeType {

	public responseCode(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}