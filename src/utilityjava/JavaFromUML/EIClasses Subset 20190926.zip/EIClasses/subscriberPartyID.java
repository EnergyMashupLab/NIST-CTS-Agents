package XSD-01.EIClasses;


/**
 * Identifier of Party subscribing to a broadcast or service
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:55 PM
 */
public class subscriberPartyID {

	public subscriberPartyID(){

	}

	public void finalize() throws Throwable {

	}

}