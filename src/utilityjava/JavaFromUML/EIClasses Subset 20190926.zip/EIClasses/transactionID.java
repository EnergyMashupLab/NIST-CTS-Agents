package XSD-01.EIClasses;


/**
 * Identification of Transaction
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:56 PM
 */
public class transactionID {

	public transactionID(){

	}

	public void finalize() throws Throwable {

	}

}