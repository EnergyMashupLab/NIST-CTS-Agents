package XSD-01.EIClasses;


/**
 * A Transaction is a specific agreement to accept a specific Tender.
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:42 PM
 */
public class EiTransactionType {

	public emix:emixBase ext_ref_27;
	public transactionID ref_element25;
	public tenderID ref_element26;

	public EiTransactionType(){

	}

	public void finalize() throws Throwable {

	}

}