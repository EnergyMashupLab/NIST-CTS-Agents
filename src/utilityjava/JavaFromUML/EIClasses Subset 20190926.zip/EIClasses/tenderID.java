package XSD-01.EIClasses;


/**
 * Identifier for a market Tender
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:56 PM
 */
public class tenderID {

	public tenderID(){

	}

	public void finalize() throws Throwable {

	}

}