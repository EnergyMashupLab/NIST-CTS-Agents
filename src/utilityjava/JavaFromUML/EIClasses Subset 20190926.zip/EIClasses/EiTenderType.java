package XSD-01.EIClasses;


/**
 * Tender is an offer to buy or sell. A Tender can be for one EmixBase derived
 * type.
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:42 PM
 */
public class EiTenderType {

	public emix:emixBase ext_ref_22;
	public tenderID ref_element21;

	public EiTenderType(){

	}

	public void finalize() throws Throwable {

	}

}