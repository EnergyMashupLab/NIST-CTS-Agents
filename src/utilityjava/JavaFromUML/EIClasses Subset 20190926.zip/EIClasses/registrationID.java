package XSD-01.EIClasses;


/**
 * Identifier for Registration transaction
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:53 PM
 */
public class registrationID {

	public registrationID(){

	}

	public void finalize() throws Throwable {

	}

}