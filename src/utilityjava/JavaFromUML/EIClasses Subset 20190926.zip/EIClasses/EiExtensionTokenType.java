package XSD-01.EIClasses;


/**
 * Pattern used for extending string enumeration, where allowed
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:40 PM
 */
public class EiExtensionTokenType extends token {

	public EiExtensionTokenType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}