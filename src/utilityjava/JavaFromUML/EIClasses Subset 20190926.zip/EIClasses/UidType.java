package XSD-01.EIClasses;


/**
 * Unique Identifier
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:57 PM
 */
public class UidType extends string {

	public UidType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}