package XSD-01.EIClasses;


/**
 * Role that Party is assuming for this interaction, e.g buyer or seller
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:49 PM
 */
public class partyRole extends string {

	public partyRole(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}