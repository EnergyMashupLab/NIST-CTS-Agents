package XSD-01.EIClasses;


/**
 * Identifier for the party publishing a broadcast message
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:51 PM
 */
public class publisherPartyID {

	public publisherPartyID(){

	}

	public void finalize() throws Throwable {

	}

}