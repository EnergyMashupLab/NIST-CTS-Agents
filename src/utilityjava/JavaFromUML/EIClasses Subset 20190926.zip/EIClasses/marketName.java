package XSD-01.EIClasses;


/**
 * Optional Name for a Market Context, used perhaps in a user interface.
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:46 PM
 */
public class marketName extends string {

	public marketName(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}