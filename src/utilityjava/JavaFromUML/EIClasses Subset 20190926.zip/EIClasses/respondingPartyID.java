package XSD-01.EIClasses;


/**
 * Identifier of Party making a Resonse (note: in CancelledPartyRegistration
 * payload and I do not know defintion)
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:53 PM
 */
public class respondingPartyID {

	public respondingPartyID(){

	}

	public void finalize() throws Throwable {

	}

}