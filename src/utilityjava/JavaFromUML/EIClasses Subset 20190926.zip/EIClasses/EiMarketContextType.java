package XSD-01.EIClasses;


/**
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:40 PM
 */
public class EiMarketContextType {

	public emix:marketContext ext_ref_1;
	public emix:envelopeContents ext_ref_3;
	public emix:standardTerms ext_ref_4;
	public schemaVersion ref_attribute7;
	/**
	 * Name associated with the Market Context
	 */
	public marketName ref_element2;
	public simpleLevelContext ref_element5;
	public createdDateTime ref_element6;

	public EiMarketContextType(){

	}

	public void finalize() throws Throwable {

	}

}