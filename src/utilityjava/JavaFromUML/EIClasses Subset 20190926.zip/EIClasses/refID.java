package XSD-01.EIClasses;


/**
 * Reference ID for a particular instance, transmittal, or artifact. Note: not the
 * same as the native ID of the object being transmitted or shared.
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:53 PM
 */
public class refID {

	public refID(){

	}

	public void finalize() throws Throwable {

	}

}