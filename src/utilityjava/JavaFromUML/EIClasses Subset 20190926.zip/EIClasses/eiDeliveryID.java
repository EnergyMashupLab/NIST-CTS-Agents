package XSD-01.EIClasses;


/**
 * Reference ID for a Delivery
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:39 PM
 */
public class eiDeliveryID {

	public eiDeliveryID(){

	}

	public void finalize() throws Throwable {

	}

}