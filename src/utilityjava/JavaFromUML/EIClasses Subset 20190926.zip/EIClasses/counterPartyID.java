package XSD-01.EIClasses;


/**
 * The "other" party in any interaction
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:36 PM
 */
public class counterPartyID {

	public counterPartyID(){

	}

	public void finalize() throws Throwable {

	}

}