package XSD-01.EIClasses;


/**
 * Identifier of a Party.  May be ws-addressing endpoint descriptor.
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:33 PM
 */
public class actorID {

	public actorID(){

	}

	public void finalize() throws Throwable {

	}

}