package XSD-01.EIClasses;


/**
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:42 PM
 */
public class EiResponseType {

	public responseCode ref_element28;
	public responseDescription ref_element29;
	/**
	 * Identifier of the Message/Request that is is a response to
	 */
	public refID ref_element30;
	public responseTermsViolated ref_element31;
	public createdDateTime ref_element32;

	public EiResponseType(){

	}

	public void finalize() throws Throwable {

	}

}