package XSD-01.EIClasses;


/**
 * Type of Reading.
 * @author crossover
 * @version 1.0
 * @created 26-Sep-2019 9:49:52 PM
 */
public class ReadingTypeType extends ReadingTypeEnumeratedType EiExtensionTokenType {

	public ReadingTypeType(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}